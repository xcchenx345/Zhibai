package com.mimo.app

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mimo.app.agent.ScreenCaptureService
import com.mimo.app.ui.screens.ChatScreen
import com.mimo.app.ui.screens.OnboardingScreen
import com.mimo.app.ui.screens.PhoneAgentScreen
import com.mimo.app.ui.theme.MiMoAppTheme
import com.mimo.app.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Register global crash handler
        Thread.setDefaultUncaughtExceptionHandler(
            com.mimo.app.data.CrashHandler(applicationContext)
        )
        setContent {
            val chatViewModel: ChatViewModel = viewModel()
            val customFontColor by chatViewModel.customFontColor.collectAsState()
            val customBgColor by chatViewModel.customBgColor.collectAsState()
            val customBubbleColor by chatViewModel.customBubbleColor.collectAsState()
            val customTextColor by chatViewModel.customTextColor.collectAsState()
            val customFontPath by chatViewModel.customFont.collectAsState()

            MiMoAppTheme(
                customFontColor = customFontColor,
                customBgColor = customBgColor,
                customBubbleColor = customBubbleColor,
                customTextColor = customTextColor,
                customFontPath = customFontPath
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val onboardingDone by chatViewModel.onboardingDone.collectAsState()
                    val showUpdatePreview by chatViewModel.showUpdatePreview.collectAsState()

                    Box(modifier = Modifier.fillMaxSize()) {
                    when (onboardingDone) {
                        // prefs still loading — blank splash, no flash of chat
                        null -> { /* intentionally empty */ }
                        // first run — show onboarding wizard
                        false -> OnboardingScreen(
                            viewModel = chatViewModel,
                            onFinished = { /* completeOnboarding already flips the flag */ }
                        )
                        // normal use — main nav
                        true -> NavHost(navController = navController, startDestination = "chat") {
                            composable("chat") {
                                ChatScreen(
                                    viewModel = chatViewModel,
                                    onNavigateToPhoneAgent = { navController.navigate("phone_agent") }
                                )
                            }
                            composable("phone_agent") {
                                PhoneAgentScreen(
                                    onBack = { navController.popBackStack() },
                                    onRequestScreenCapture = {
                                        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                        @Suppress("DEPRECATION")
                                        startActivityForResult(mgr.createScreenCaptureIntent(), ScreenCaptureService.REQUEST_CODE)
                                    }
                                )
                            }
                        }
                    }

                    // Update preview overlay
                    if (showUpdatePreview) {
                        com.mimo.app.ui.screens.UpdatePreviewScreen(
                            onDismiss = { chatViewModel.dismissUpdatePreview() }
                        )
                    }

                    // Crash report dialog — show on next launch after a crash
                    var crashLog by remember { mutableStateOf(com.mimo.app.data.CrashHandler.readCrashLog(applicationContext)) }
                    val currentCrashLog = crashLog
                    if (currentCrashLog != null) {
                        // Also post a notification as fallback
                        androidx.compose.runtime.LaunchedEffect(currentCrashLog) {
                            try {
                                val channelId = "crash_channel"
                                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                                if (android.os.Build.VERSION.SDK_INT >= 26) {
                                    nm.createNotificationChannel(android.app.NotificationChannel(
                                        channelId, "崩溃报告", android.app.NotificationManager.IMPORTANCE_HIGH
                                    ))
                                }
                                val pendingIntent = android.app.PendingIntent.getActivity(
                                    this@MainActivity, 0,
                                    Intent(this@MainActivity, MainActivity::class.java),
                                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                                )
                                val notif = if (android.os.Build.VERSION.SDK_INT >= 26) {
                                    android.app.Notification.Builder(this@MainActivity, channelId)
                                } else {
                                    @Suppress("DEPRECATION")
                                    android.app.Notification.Builder(this@MainActivity)
                                }
                                    .setContentTitle("上次运行发生崩溃")
                                    .setContentText(currentCrashLog.take(100).replace('\n', ' '))
                                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                                    .setContentIntent(pendingIntent)
                                    .setAutoCancel(true)
                                    .build()
                                nm.notify(9999, notif)
                            } catch (_: Exception) {}
                        }
                        com.mimo.app.ui.screens.CrashReportDialog(
                            crashLog = currentCrashLog,
                            onAnalyze = { log ->
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                    chatViewModel.analyzeCrash(log)
                                }
                            },
                            onBackupChats = { chatViewModel.backupAllChats() },
                            onDismiss = {
                                com.mimo.app.data.CrashHandler.clearCrashLog(applicationContext)
                                finish()
                                android.os.Process.killProcess(android.os.Process.myPid())
                            }
                        )
                    }
                    } // end Box
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ScreenCaptureService.REQUEST_CODE) {
            ScreenCaptureService.onPermissionResult(resultCode, data, this)
        }
    }
}
