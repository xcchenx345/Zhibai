package com.mimo.app

import android.app.Application
import com.mimo.app.adb.AdbManager

class MiMoApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        AdbManager.init(this)
    }
}
