package com.mimo.app.agent

import android.content.Context
import android.os.Environment
import com.mimo.app.data.api.MiMoApiService
import com.google.gson.Gson
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URLConnection
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

data class AgentTool(
    val name: String,
    val description: String,
    val riskLevel: Int,
    var enabled: Boolean = true,
    var requireConfirmation: Boolean = false,
    val category: String = "other",
    val execute: suspend (Map<String, Any>, Context) -> String
)

data class AgentTask(
    val id: String = java.util.UUID.randomUUID().toString(),
    val prompt: String,
    val status: String = "pending",
    val result: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class ToolPermission(
    val toolName: String,
    val enabled: Boolean,
    val requireConfirmation: Boolean
)

data class PendingConfirmation(
    val toolName: String,
    val args: Map<String, Any>,
    val description: String,
    val continuation: CancellableContinuation<Boolean>
)

class AgentEngine(
    private val context: Context,
    private val apiService: MiMoApiService,
    private val workspaceOverride: String? = null,
    private val taskManager: AgentTaskManager = AgentTaskManager()
) {
    private val gson = Gson()
    val workspaceDir: File = resolveWorkspace()

    private fun tryMakeWritable(dir: File): Boolean {
        return try {
            if (!dir.exists()) dir.mkdirs()
            if (dir.isDirectory) {
                val probe = File(dir, ".write_probe")
                probe.writeText("ok")
                probe.delete()
                true
            } else false
        } catch (_: Exception) { false }
    }

    private fun resolveWorkspace(): File {
        val external = Environment.getExternalStorageDirectory()
        workspaceOverride?.trim()?.takeIf { it.isNotBlank() }?.let { raw ->
            val custom = if (raw.startsWith("/")) File(raw) else File(external, raw)
            if (tryMakeWritable(custom)) return custom
        }
        val default = File(external, "知白")
        if (tryMakeWritable(default)) return default
        return File(context.filesDir, "mimo_agent").apply { mkdirs() }
    }
    private val skillsDir = File(workspaceDir, "skills").apply { mkdirs() }
    private val outputDir = File(workspaceDir, "output").apply { mkdirs() }

    val tools = mutableListOf<AgentTool>()
    private val scheduledTasks = mutableListOf<AgentTask>()

    var pendingConfirmation: PendingConfirmation? = null
        private set

    private val disabledTools = ConcurrentHashMap.newKeySet<String>()
    private val confirmTools = ConcurrentHashMap.newKeySet<String>()

    private val sensitivePrefixes = listOf("/proc", "/sys", "/data/data", "/dev")

    var zhipuApiKey: String = ""

    /** Invoked when a tool call is waiting for user approval (wires to UI dialog). */
    var onConfirmationRequested: ((toolName: String, args: Map<String, Any>, description: String) -> Unit)? = null

    companion object {
        const val MODE_ASK_ALL = 0        // 所有调用需要审批
        const val MODE_DEFAULT = 1        // 默认权限：低风险放行，高风险询问
        const val MODE_AUTO = 2           // 全部放行不询问
        const val MODE_AI_APPROVE = 3     // AI 先审批，AI 拒绝则流放给用户

        /** Master switch for ALL phone-control features (AutoGLM / PhoneAgent). Set true to re-enable. */
        const val PHONE_AGENT_ENABLED = false
    }

    init {
        try { initAgentFiles() } catch (_: Exception) {}
        registerBuiltInTools()
    }

    fun loadZhipuKeyFromPrefs(context: Context) {
        if (zhipuApiKey.isBlank()) {
            try {
                val prefs = context.getSharedPreferences("mimo_settings", Context.MODE_PRIVATE)
                zhipuApiKey = prefs.getString("zhipu_api_key", "") ?: ""
            } catch (_: Exception) {}
        }
    }

    fun resolvePath(path: String): File {
        val file = File(path)
        return if (file.isAbsolute) file else File(workspaceDir, path)
    }

    fun validatePath(file: File): Boolean {
        val canonical = file.canonicalPath
        if (sensitivePrefixes.any { canonical.startsWith(it) }) return false
        return true
    }

    /** True if the app holds "All files access" (required to see non-app files on shared storage). */
    fun hasAllFilesAccess(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 30) {
            try { android.os.Environment.isExternalStorageManager() } catch (_: Exception) { false }
        } else {
            true
        }
    }

    /** Warning suffix when listing shared storage without All files access (FUSE hides file entries). */
    private fun storageWarning(dir: File): String {
        if (hasAllFilesAccess()) return ""
        val external = try { Environment.getExternalStorageDirectory().canonicalPath } catch (_: Exception) { return "" }
        return if (dir.canonicalPath.startsWith(external)) {
            "\n\n⚠️ \"All files access\" is NOT granted — Android is hiding file entries (only folders visible). " +
                "Grant it in Settings > Apps > MiMo > Permissions > All files access, then retry."
        } else ""
    }

    private fun initAgentFiles() {
        val files = mapOf(
            "IDENTITY.md" to """# Identity
You are MiMo Agent, a local AI assistant running on the user's Android device.
You operate autonomously within the user's granted permissions.
Your workspace is at ${workspaceDir.absolutePath}.""".trimIndent(),

            "SOUL.md" to """# Soul
## Core Principles
- Be genuinely useful, not performatively helpful
- Have opinions, be direct, skip pleasantries
- Try to figure things out yourself before asking
- Respect user's time - concise answers, clean code

## Personality
- Efficient and straightforward
- Slightly opinionated but respectful
- Action-oriented over explanation-oriented""".trimIndent(),

            "AGENTS.md" to """# Agent Protocol
## When to Act Autonomously
- File operations within workspace ($workspaceDir)
- Reading device info
- Listing installed apps

## When to Ask Permission
- Modifying files outside workspace (risk level 3+)
- Deleting files (risk level 4+)
- ADB commands (risk level 5)

## Workflow
1. Understand the request
2. Plan the steps
3. Execute with appropriate caution
4. Report results concisely""".trimIndent(),

            "TOOLS.md" to """# Available Tools
- read_file: Read file content (risk: 1)
- write_file: Write to file (risk: 3)
- list_files: List directory contents (risk: 1)
- delete_file: Delete file/folder (risk: 4)
- move_file: Move/rename file (risk: 3)
- copy_file: Copy file (risk: 2)
- search_files: Search files by name pattern (risk: 1)
- get_file_info: Get file metadata (risk: 1)
- grep: Search inside file contents, regex (risk: 1)
- edit_file: Replace exact string in a file (risk: 3)
- current_time: Current date/time (risk: 1)
- download_file: Download URL into workspace (risk: 3)
- view_media: View/analyze an image, audio, or video file and get a description/transcript (risk: 1)
- request_permission: Ask user to grant system permission (risk: 1)
- open_app: Launch Android app (risk: 2)
- list_apps: List installed apps (risk: 1)
- execute_phone_action: Execute phone action via AutoGLM (risk: 3)
- run_adb: Execute shell command (risk: 5)
- get_device_info: Device information (risk: 1)
- fetch_url: Fetch web page content (risk: 2)
- save_skill: Save reusable workflow (risk: 2)
- read_skill: Read saved skill (risk: 1)
- list_skills: List all skills (risk: 1)""".trimIndent(),

            "MEMORY.md" to """# Memory
## Learned Preferences
(none yet)

## Past Context
(none yet)""".trimIndent(),

            "USER.md" to """# User Profile
- Location: Wenzhou, Zhejiang, China
- Timezone: Asia/Shanghai (UTC+8)
- Prefers concise, efficient tools
- Technical enthusiast""".trimIndent(),

            "HEARTBEAT.md" to """# Heartbeat
Last active: ${java.time.LocalDateTime.now()}
Status: Ready
Workspace: ${workspaceDir.absolutePath}
Skills: ${skillsDir.listFiles()?.size ?: 0}"""
        )

        files.forEach { (name, content) ->
            val file = File(workspaceDir, name)
            if (!file.exists()) file.writeText(content)
        }
    }

    /** Force-write workspace files (used by onboarding personalization). */
    fun writeWorkspaceFiles(files: Map<String, String>) {
        files.forEach { (name, content) ->
            if (name.contains('/') || name.contains('\\') || name.contains("..")) return@forEach
            File(workspaceDir, name).writeText(content)
        }
    }

    fun getAgentContext(): String {
        updateHeartbeat()
        return buildString {
            appendLine("=== Agent Workspace Context ===")
            appendLine("Workspace: ${workspaceDir.absolutePath}")
            appendLine("Skills: ${skillsDir.listFiles()?.map { it.nameWithoutExtension }?.joinToString() ?: "none"}")
            appendLine()
            listOf("IDENTITY.md", "SOUL.md", "TOOLS.md").forEach { name ->
                val file = File(workspaceDir, name)
                if (file.exists()) {
                    appendLine("### $name")
                    appendLine(file.readText())
                    appendLine()
                }
            }
        }
    }

    fun updateHeartbeat() {
        try {
            File(workspaceDir, "HEARTBEAT.md").writeText(
                """# Heartbeat
Last active: ${java.time.LocalDateTime.now()}
Status: Active
Workspace: ${workspaceDir.absolutePath}
Skills: ${skillsDir.listFiles()?.size ?: 0}
Tasks: ${scheduledTasks.size}""".trimIndent()
            )
        } catch (_: Exception) {}
    }

    private fun registerBuiltInTools() {
        // read_file
        tools.add(AgentTool(
            name = "read_file", description = "Read the content of a file", riskLevel = 1, category = "file"
        ) { args, _ ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            if (!file.exists()) return@AgentTool "Error: file not found"
            if (file.length() > 1024 * 1024) return@AgentTool "Error: file too large (>1MB)"
            file.readText()
        })

        // write_file
        tools.add(AgentTool(
            name = "write_file", description = "Write content to a file", riskLevel = 3, category = "file"
        ) { args, _ ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val content = args["content"] as? String ?: return@AgentTool "Error: no content"
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            file.parentFile?.mkdirs()
            file.writeText(content)
            "Written ${content.length} bytes to ${file.absolutePath}"
        })

        // list_files
        tools.add(AgentTool(
            name = "list_files", description = "List files in a directory", riskLevel = 1, category = "file"
        ) { args, _ ->
            val path = args["path"] as? String ?: workspaceDir.absolutePath
            val dir = resolvePath(path)
            if (!validatePath(dir)) return@AgentTool "Error: access denied"
            if (!dir.exists() || !dir.isDirectory) return@AgentTool "Error: not a directory"
            val list = dir.listFiles()?.joinToString("\n") { "${if (it.isDirectory) "[DIR]" else "[FILE]"} ${it.name}" } ?: "Empty directory"
            list + storageWarning(dir)
        })

        // delete_file
        tools.add(AgentTool(
            name = "delete_file", description = "Delete a file or directory", riskLevel = 4, category = "file"
        ) { args, _ ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            if (!file.exists()) return@AgentTool "Error: file not found"
            if (file.deleteRecursively()) "Deleted ${file.absolutePath}" else "Error: failed to delete"
        })

        // move_file
        tools.add(AgentTool(
            name = "move_file", description = "Move or rename a file/directory", riskLevel = 3, category = "file"
        ) { args, _ ->
            val source = args["source"] as? String ?: return@AgentTool "Error: no source"
            val dest = args["destination"] as? String ?: return@AgentTool "Error: no destination"
            val srcFile = resolvePath(source)
            val dstFile = resolvePath(dest)
            if (!validatePath(srcFile) || !validatePath(dstFile)) return@AgentTool "Error: access denied"
            if (!srcFile.exists()) return@AgentTool "Error: source not found"
            dstFile.parentFile?.mkdirs()
            if (srcFile.renameTo(dstFile)) {
                "Moved ${srcFile.absolutePath} -> ${dstFile.absolutePath}"
            } else {
                srcFile.copyTo(dstFile, overwrite = true)
                srcFile.deleteRecursively()
                "Moved (copy+delete) ${srcFile.absolutePath} -> ${dstFile.absolutePath}"
            }
        })

        // copy_file
        tools.add(AgentTool(
            name = "copy_file", description = "Copy a file or directory", riskLevel = 2, category = "file"
        ) { args, _ ->
            val source = args["source"] as? String ?: return@AgentTool "Error: no source"
            val dest = args["destination"] as? String ?: return@AgentTool "Error: no destination"
            val srcFile = resolvePath(source)
            val dstFile = resolvePath(dest)
            if (!validatePath(srcFile) || !validatePath(dstFile)) return@AgentTool "Error: access denied"
            if (!srcFile.exists()) return@AgentTool "Error: source not found"
            dstFile.parentFile?.mkdirs()
            if (srcFile.isDirectory) {
                srcFile.copyRecursively(dstFile, overwrite = true)
            } else {
                srcFile.copyTo(dstFile, overwrite = true)
            }
            "Copied ${srcFile.absolutePath} -> ${dstFile.absolutePath}"
        })

        // search_files
        tools.add(AgentTool(
            name = "search_files", description = "Search files by name pattern", riskLevel = 1, category = "file"
        ) { args, _ ->
            val pattern = args["pattern"] as? String ?: return@AgentTool "Error: no pattern"
            val path = args["path"] as? String ?: workspaceDir.absolutePath
            val dir = resolvePath(path)
            if (!validatePath(dir)) return@AgentTool "Error: access denied"
            if (!dir.exists() || !dir.isDirectory) return@AgentTool "Error: not a directory"
            val regex = try { Regex(pattern, RegexOption.IGNORE_CASE) } catch (_: Exception) { Regex(Regex.escape(pattern), RegexOption.IGNORE_CASE) }
            val results = mutableListOf<String>()
            dir.walkTopDown().maxDepth(10).forEach { f ->
                if (results.size >= 50) return@forEach
                if (regex.containsMatchIn(f.name)) {
                    results.add("${if (f.isDirectory) "[DIR]" else "[FILE]"} ${f.absolutePath}")
                }
            }
            if (results.isEmpty()) "No files found matching '$pattern'" else results.joinToString("\n")
            .plus(storageWarning(dir))
        })

        // get_file_info
        tools.add(AgentTool(
            name = "get_file_info", description = "Get file metadata (size, type, modified date)", riskLevel = 1, category = "file"
        ) { args, _ ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            if (!file.exists()) return@AgentTool "Error: file not found"
            buildString {
                appendLine("Path: ${file.absolutePath}")
                appendLine("Type: ${if (file.isDirectory) "Directory" else "File"}")
                appendLine("Size: ${file.length()} bytes")
                appendLine("Modified: ${java.util.Date(file.lastModified())}")
                if (file.isFile) {
                    val mime = URLConnection.guessContentTypeFromName(file.name) ?: "unknown"
                    appendLine("MIME: $mime")
                }
                appendLine("Readable: ${file.canRead()}")
                appendLine("Writable: ${file.canWrite()}")
            }
        })

        // grep — search file CONTENTS (like a real coding agent)
        tools.add(AgentTool(
            name = "grep",
            description = "Search inside file contents (like ripgrep). Args: pattern (regex or literal), path (dir, default workspace), include (glob like *.kt, optional)",
            riskLevel = 1, category = "file"
        ) { args, _ ->
            val pattern = args["pattern"] as? String ?: return@AgentTool "Error: no pattern"
            val path = args["path"] as? String ?: workspaceDir.absolutePath
            val include = args["include"] as? String
            val dir = resolvePath(path)
            if (!validatePath(dir)) return@AgentTool "Error: access denied"
            if (!dir.exists()) return@AgentTool "Error: path not found"
            val regex = try { Regex(pattern) } catch (_: Exception) { Regex(Regex.escape(pattern)) }
            val includeGlob = include?.let { glob -> Regex(Regex.escape(glob).replace("\\*", ".*")) }
            val results = mutableListOf<String>()
            val filesToScan = if (dir.isFile) listOf(dir) else dir.walkTopDown().maxDepth(10)
                .filter { it.isFile }
                .filter { f -> includeGlob == null || includeGlob.matches(f.name) }
                .toList()
            for (f in filesToScan) {
                if (results.size >= 50) break
                if (f.length() > 2_000_000) continue // skip >2MB files
                try {
                    f.forEachLine { line ->
                        if (results.size >= 50) return@forEachLine
                        if (regex.containsMatchIn(line)) {
                            val rel = f.relativeToOrSelf(dir).path
                            results.add("$rel:${line.trim().take(200)}")
                        }
                    }
                } catch (_: Exception) {}
            }
            if (results.isEmpty()) "No matches for '$pattern'" else results.joinToString("\n")
        })

        // edit_file — precise string replacement (no full rewrite needed)
        tools.add(AgentTool(
            name = "edit_file",
            description = "Replace an exact string in a file (single occurrence). Args: path, old_text (must match exactly), new_text",
            riskLevel = 3, category = "file"
        ) { args, _ ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val oldText = args["old_text"] as? String ?: return@AgentTool "Error: no old_text"
            val newText = args["new_text"] as? String ?: return@AgentTool "Error: no new_text"
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            if (!file.exists() || !file.isFile) return@AgentTool "Error: file not found"
            val content = try { file.readText() } catch (e: Exception) { return@AgentTool "Error: ${e.message}" }
            val count = content.split(oldText).size - 1
            when {
                count == 0 -> return@AgentTool "Error: old_text not found in file"
                count > 1 -> return@AgentTool "Error: old_text matches $count times — make it more specific (add surrounding context)"
                else -> {
                    file.writeText(content.replaceFirst(oldText, newText))
                    "Replaced 1 occurrence in ${file.absolutePath}"
                }
            }
        })

        // current_time
        tools.add(AgentTool(
            name = "current_time", description = "Get current date and time (device timezone)", riskLevel = 1, category = "system"
        ) { _, _ ->
            val now = java.time.LocalDateTime.now()
            val zone = java.time.ZoneId.systemDefault()
            "$now (${zone.id}) · ${java.time.LocalDate.now().dayOfWeek}"
        })

        // download_file
        tools.add(AgentTool(
            name = "download_file",
            description = "Download a file from a URL into the workspace. Args: url, filename (optional)",
            riskLevel = 3, category = "network"
        ) { args, _ ->
            val url = args["url"] as? String ?: return@AgentTool "Error: no url"
            val filename = (args["filename"] as? String)?.replace(Regex("[^A-Za-z0-9._-]"), "_")
                ?: java.net.URL(url).path.substringAfterLast('/').ifBlank { "download.bin" }
            if (!filename.contains('.')) return@AgentTool "Error: filename must have an extension"
            try {
                val conn = java.net.URL(url).openConnection().apply {
                    connectTimeout = 15_000
                    readTimeout = 60_000
                }
                val total = conn.contentLengthLong
                if (total > 100L * 1024 * 1024) return@AgentTool "Error: file too large (${total / 1024 / 1024}MB > 100MB)"
                conn.getInputStream().use { input ->
                    File(workspaceDir, filename).outputStream().use { out ->
                        input.copyTo(out, bufferSize = 64 * 1024)
                    }
                }
                val saved = File(workspaceDir, filename)
                "Downloaded ${saved.length()} bytes to ${saved.absolutePath}"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // view_media — autonomously look at an image / listen to audio / watch a video
        tools.add(AgentTool(
            name = "view_media",
            description = "View/analyze a local media file (image, audio, or video) and get a description or transcription. Args: path (required), question (optional — what to look for / ask about the media)",
            riskLevel = 1, category = "media"
        ) { args, _ ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val question = args["question"] as? String
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            if (!file.exists() || !file.isFile) return@AgentTool "Error: file not found"

            val mime = URLConnection.guessContentTypeFromName(file.name.lowercase()) ?: ""
            val isImage = mime.startsWith("image/")
            val isAudio = mime.startsWith("audio/")
            val isVideo = mime.startsWith("video/")
            if (!isImage && !isAudio && !isVideo) {
                return@AgentTool "Error: unsupported media type '$mime' (only image/audio/video)"
            }

            // size caps: image 15MB, audio 25MB, video 40MB (base64 blows up ~1.33x)
            val capBytes = when {
                isImage -> 15L * 1024 * 1024
                isAudio -> 25L * 1024 * 1024
                else -> 40L * 1024 * 1024
            }
            if (file.length() > capBytes) {
                return@AgentTool "Error: file too large (${file.length() / 1024 / 1024}MB > ${capBytes / 1024 / 1024}MB)"
            }

            val b64 = try {
                android.util.Base64.encodeToString(file.readBytes(), android.util.Base64.NO_WRAP)
            } catch (e: Exception) {
                return@AgentTool "Error reading file: ${e.message}"
            }

            val prompt = question?.takeIf { it.isNotBlank() } ?: when {
                isImage -> "Describe this image in detail. If there is text, transcribe it."
                isAudio -> "Transcribe and summarize this audio."
                else -> "Describe what happens in this video."
            }

            val userMsg = apiService.buildUserMessage(
                text = prompt,
                imageBase64 = if (isImage) b64 else null,
                audioBase64 = if (isAudio) b64 else null,
                audioMimeType = if (isAudio) mime else null,
                videoBase64 = if (isVideo) b64 else null,
                videoMimeType = if (isVideo) mime else null,
                mimeType = mime.ifBlank { "image/jpeg" }
            )
            val req = com.mimo.app.data.model.ChatRequest(
                model = "mimo-v2.6-flash",
                messages = listOf(
                    com.mimo.app.data.model.Message(role = "system", content = "You are a precise media analyst. Describe/transcribe only what is actually present. Be concise."),
                    userMsg
                ),
                maxCompletionTokens = 2048,
                temperature = 0.3f,
                stream = false,
                thinking = com.mimo.app.data.model.ThinkingConfig(type = "disabled")
            )
            try {
                val desc = apiService.chatCompleteText(req)
                if (desc.isNullOrBlank()) "Error: model returned no description for ${file.name}"
                else "[${file.name} · $mime]\n$desc"
            } catch (e: Exception) {
                "Error analyzing media: ${e.message}"
            }
        })

        // open_app
        tools.add(AgentTool(
            name = "open_app", description = "Open an Android app by package name", riskLevel = 2, category = "app"
        ) { args, ctx ->
            val packageName = args["package"] as? String ?: return@AgentTool "Error: no package"
            try {
                val intent = ctx.packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(intent)
                    "Opened $packageName"
                } else {
                    "Error: app not found"
                }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // list_apps
        tools.add(AgentTool(
            name = "list_apps", description = "List installed apps", riskLevel = 1, category = "app"
        ) { _, ctx ->
            ctx.packageManager.getInstalledApplications(0)
                .filter { ctx.packageManager.getLaunchIntentForPackage(it.packageName) != null }
                .map { "${it.loadLabel(ctx.packageManager)} (${it.packageName})" }
                .sorted()
                .joinToString("\n")
        })

        // === Device tools ===

        // get_location
        tools.add(AgentTool(
            name = "get_location", description = "Get current GPS location (latitude, longitude)", riskLevel = 2, category = "device"
        ) { _, ctx ->
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
                val provider = when {
                    lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) -> android.location.LocationManager.GPS_PROVIDER
                    lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) -> android.location.LocationManager.NETWORK_PROVIDER
                    else -> return@AgentTool "Error: no location provider enabled"
                }
                @Suppress("MissingPermission")
                val loc = lm.getLastKnownLocation(provider)
                    ?: return@AgentTool "Error: no location available. Grant location permission and try again."
                "Lat: ${loc.latitude}, Lng: ${loc.longitude}, Accuracy: ${loc.accuracy}m, Provider: $provider"
            } catch (e: SecurityException) {
                "NEED_PERMISSION:storage|Location permission is required"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // set_alarm
        tools.add(AgentTool(
            name = "set_alarm", description = "Set an alarm. Args: hour (0-23), minute (0-59), label (optional)", riskLevel = 1, category = "device"
        ) { args, ctx ->
            val hour = (args["hour"] as? Number)?.toInt() ?: return@AgentTool "Error: no hour"
            val minute = (args["minute"] as? Number)?.toInt() ?: 0
            val label = args["label"] as? String ?: "Alarm"
            try {
                val intent = android.content.Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
                    putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                }
                ctx.startActivity(intent)
                "Alarm set for ${hour}:${minute.toString().padStart(2, '0')} - $label"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // set_timer
        tools.add(AgentTool(
            name = "set_timer", description = "Set a timer. Args: seconds (duration), label (optional)", riskLevel = 1, category = "device"
        ) { args, ctx ->
            val seconds = (args["seconds"] as? Number)?.toLong() ?: return@AgentTool "Error: no seconds"
            val label = args["label"] as? String ?: "Timer"
            try {
                val intent = android.content.Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                }
                ctx.startActivity(intent)
                "Timer set for ${seconds}s - $label"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // set_volume
        tools.add(AgentTool(
            name = "set_volume", description = "Set media volume. Args: level (0-15)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val level = (args["level"] as? Number)?.toInt()?.coerceIn(0, 15) ?: return@AgentTool "Error: no level (0-15)"
            try {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, level, 0)
                "Media volume set to $level/15"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // get_volume
        tools.add(AgentTool(
            name = "get_volume", description = "Get current media volume level", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                val current = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                "Media volume: $current/$max"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // toggle_flashlight
        tools.add(AgentTool(
            name = "toggle_flashlight", description = "Toggle flashlight on/off. Args: state (on/off)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val state = (args["state"] as? String)?.lowercase() ?: return@AgentTool "Error: no state (on/off)"
            try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
                val cameraId = cm.cameraIdList.firstOrNull { id ->
                    cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return@AgentTool "Error: no flashlight available"
                cm.setTorchMode(cameraId, state == "on")
                "Flashlight ${if (state == "on") "ON" else "OFF"}"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // get_network_info
        tools.add(AgentTool(
            name = "get_network_info", description = "Get network status (WiFi, mobile data, signal)", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
                val network = cm.activeNetwork
                val caps = cm.getNetworkCapabilities(network)
                val wifi = caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
                val mobile = caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true
                val connected = caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
                val type = when {
                    wifi -> "WiFi"
                    mobile -> "Mobile Data"
                    else -> "None"
                }
                val ssid = if (wifi) {
                    try {
                        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                        @Suppress("MissingPermission")
                        wm.connectionInfo?.ssid?.replace("\"", "") ?: "unknown"
                    } catch (_: Exception) { "unknown" }
                } else ""
                "Type: $type, Connected: $connected${if (ssid.isNotBlank()) ", SSID: $ssid" else ""}"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // get_battery_info
        tools.add(AgentTool(
            name = "get_battery_info", description = "Get battery level, charging status, temperature", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                val level = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val charging = bm.isCharging
                val temp = try {
                    val f = java.io.File("/sys/class/power_supply/battery/temp")
                    if (f.exists()) (f.readText().trim().toFloat() / 10f).toString() + "°C" else "unknown"
                } catch (_: Exception) { "unknown" }
                "Battery: $level%, Charging: $charging, Temp: $temp"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // get_device_info_extended
        tools.add(AgentTool(
            name = "get_device_details", description = "Get detailed device info: RAM, storage, screen, CPU", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val rt = Runtime.getRuntime()
                val totalMem = rt.totalMemory() / 1024 / 1024
                val freeMem = rt.freeMemory() / 1024 / 1024
                val stat = android.os.StatFs(ctx.filesDir.path)
                val totalStorage = stat.blockCountLong * stat.blockSizeLong / 1024 / 1024
                val freeStorage = stat.availableBlocksLong * stat.blockSizeLong / 1024 / 1024
                val dm = ctx.resources.displayMetrics
                val dpi = dm.densityDpi
                buildString {
                    appendLine("Model: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                    appendLine("Android: ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
                    appendLine("RAM: ${totalMem}MB total, ${freeMem}MB free")
                    appendLine("Storage: ${totalStorage}MB total, ${freeStorage}MB free")
                    appendLine("Screen: ${dm.widthPixels}x${dm.heightPixels} @ ${dpi}dpi")
                    appendLine("CPU: ${android.os.Build.HARDWARE}")
                }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // make_call (dangerous - needs confirmation)
        tools.add(AgentTool(
            name = "make_call", description = "Open phone dialer with number. Args: number (phone number)", riskLevel = 4, category = "phone"
        ) { args, ctx ->
            val number = args["number"] as? String ?: return@AgentTool "Error: no number"
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_DIAL,
                    android.net.Uri.parse("tel:$number"))
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Dialer opened for $number"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // open_settings
        tools.add(AgentTool(
            name = "open_settings", description = "Open a system settings page. Args: page (wifi|bluetooth|location|sound|display|battery|apps|storage|about)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val page = (args["page"] as? String)?.lowercase() ?: return@AgentTool "Error: no page"
            val action = when (page) {
                "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
                "location" -> android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "sound" -> android.provider.Settings.ACTION_SOUND_SETTINGS
                "display" -> android.provider.Settings.ACTION_DISPLAY_SETTINGS
                "battery" -> android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS
                "apps" -> android.provider.Settings.ACTION_APPLICATION_SETTINGS
                "storage" -> android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                "about" -> android.provider.Settings.ACTION_DEVICE_INFO_SETTINGS
                else -> return@AgentTool "Error: unknown page '$page'. Use: wifi|bluetooth|location|sound|display|battery|apps|storage|about"
            }
            try {
                val intent = android.content.Intent(action).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
                "Opened settings: $page"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // share_text
        tools.add(AgentTool(
            name = "share_text", description = "Open share sheet with text. Args: text (content to share)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val text = args["text"] as? String ?: return@AgentTool "Error: no text"
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(android.content.Intent.EXTRA_TEXT, text)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(android.content.Intent.createChooser(intent, "Share via"))
                "Share sheet opened"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // vibrate
        tools.add(AgentTool(
            name = "vibrate", description = "Vibrate the device. Args: milliseconds (duration, default 200)", riskLevel = 1, category = "device"
        ) { args, ctx ->
            val ms = (args["milliseconds"] as? Number)?.toLong() ?: 200L
            try {
                val vm = ctx.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
                @Suppress("DEPRECATION")
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    vm.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vm.vibrate(ms)
                }
                "Vibrated for ${ms}ms"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // === Extended device tools ===

        // clipboard_read
        tools.add(AgentTool(
            name = "clipboard_read", description = "Read current clipboard content", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = cm.primaryClip
                if (clip == null || clip.itemCount == 0) "Clipboard is empty"
                else (0 until clip.itemCount).joinToString("\n") { i ->
                    clip.getItemAt(i).coerceToText(ctx)?.toString() ?: "(unavailable)"
                }
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // clipboard_write
        tools.add(AgentTool(
            name = "clipboard_write", description = "Write text to clipboard. Args: text", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val text = args["text"] as? String ?: return@AgentTool "Error: no text"
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("agent", text))
                "Copied to clipboard (${text.length} chars)"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // set_brightness
        tools.add(AgentTool(
            name = "set_brightness", description = "Set screen brightness. Args: level (0-255)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val level = (args["level"] as? Number)?.toInt()?.coerceIn(0, 255) ?: return@AgentTool "Error: no level (0-255)"
            try {
                android.provider.Settings.System.putInt(ctx.contentResolver,
                    android.provider.Settings.System.SCREEN_BRIGHTNESS, level)
                "Brightness set to $level/255"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // set_sound_mode
        tools.add(AgentTool(
            name = "set_sound_mode", description = "Set ringer mode. Args: mode (normal|vibrate|silent)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val mode = (args["mode"] as? String)?.lowercase() ?: return@AgentTool "Error: no mode"
            try {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                when (mode) {
                    "normal" -> am.ringerMode = android.media.AudioManager.RINGER_MODE_NORMAL
                    "vibrate" -> am.ringerMode = android.media.AudioManager.RINGER_MODE_VIBRATE
                    "silent" -> am.ringerMode = android.media.AudioManager.RINGER_MODE_SILENT
                    else -> return@AgentTool "Error: use normal|vibrate|silent"
                }
                "Sound mode: $mode"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // get_sound_mode
        tools.add(AgentTool(
            name = "get_sound_mode", description = "Get current ringer mode", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                when (am.ringerMode) {
                    android.media.AudioManager.RINGER_MODE_NORMAL -> "Sound mode: normal"
                    android.media.AudioManager.RINGER_MODE_VIBRATE -> "Sound mode: vibrate"
                    android.media.AudioManager.RINGER_MODE_SILENT -> "Sound mode: silent"
                    else -> "Sound mode: unknown"
                }
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // close_app
        tools.add(AgentTool(
            name = "close_app", description = "Force-stop an app. Args: package (package name)", riskLevel = 3, category = "app"
        ) { args, ctx ->
            val pkg = args["package"] as? String ?: return@AgentTool "Error: no package"
            try {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                am.killBackgroundProcesses(pkg)
                "App $pkg stopped"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // get_app_info
        tools.add(AgentTool(
            name = "get_app_info", description = "Get app details. Args: package", riskLevel = 1, category = "app"
        ) { args, ctx ->
            val pkg = args["package"] as? String ?: return@AgentTool "Error: no package"
            try {
                val pm = ctx.packageManager
                val info = pm.getPackageInfo(pkg, 0)
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0))
                val size = try {
                    pm.getApplicationInfo(pkg, 0).sourceDir?.let { java.io.File(it).length() / 1024 / 1024 } ?: 0
                } catch (_: Exception) { 0 }
                buildString {
                    appendLine("Name: $label")
                    appendLine("Package: $pkg")
                    appendLine("Version: ${info.versionName} (${info.longVersionCode})")
                    appendLine("Size: ~${size}MB")
                    appendLine("First install: ${java.time.Instant.ofEpochMilli(info.firstInstallTime)}")
                    appendLine("Last update: ${java.time.Instant.ofEpochMilli(info.lastUpdateTime)}")
                }
            } catch (e: Exception) { "Error: app not found: $pkg" }
        })

        // install_apk
        tools.add(AgentTool(
            name = "install_apk", description = "Install an APK file. Args: path (path to .apk file). Requires user confirmation.", riskLevel = 4, category = "app"
        ) { args, ctx ->
            val path = args["path"] as? String ?: return@AgentTool "Error: no path"
            val file = resolvePath(path)
            if (!validatePath(file)) return@AgentTool "Error: access denied"
            if (!file.exists() || !file.isFile) return@AgentTool "Error: file not found: $path"
            if (!file.name.endsWith(".apk", ignoreCase = true)) return@AgentTool "Error: not an APK file"
            try {
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    ctx, "${ctx.packageName}.fileprovider", file)
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
                "Install prompt opened for ${file.name} (${file.length() / 1024 / 1024}MB). User must confirm in system dialog."
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // uninstall_app
        tools.add(AgentTool(
            name = "uninstall_app", description = "Uninstall an app by package name. Args: package. Requires user confirmation.", riskLevel = 5, category = "app"
        ) { args, ctx ->
            val pkg = args["package"] as? String ?: return@AgentTool "Error: no package"
            if (pkg == ctx.packageName) return@AgentTool "Error: cannot uninstall self"
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_DELETE,
                    android.net.Uri.parse("package:$pkg")).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
                "Uninstall confirmation opened for $pkg. User must confirm."
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // download_and_install
        tools.add(AgentTool(
            name = "download_and_install", description = "Download an APK from URL and open install prompt. Args: url. Requires user confirmation.", riskLevel = 5, category = "app"
        ) { args, ctx ->
            val url = args["url"] as? String ?: return@AgentTool "Error: no url"
            try {
                val filename = java.net.URL(url).path.substringAfterLast('/').ifBlank { "download.apk" }
                if (!filename.endsWith(".apk", ignoreCase = true)) return@AgentTool "Error: URL must point to an .apk file"
                val conn = java.net.URL(url).openConnection().apply {
                    connectTimeout = 15_000
                    readTimeout = 120_000
                }
                val total = conn.contentLengthLong
                if (total > 200L * 1024 * 1024) return@AgentTool "Error: APK too large (${total / 1024 / 1024}MB > 200MB)"
                val saved = java.io.File(workspaceDir, filename)
                conn.getInputStream().use { input ->
                    saved.outputStream().use { out -> input.copyTo(out, bufferSize = 64 * 1024) }
                }
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    ctx, "${ctx.packageName}.fileprovider", saved)
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
                "Downloaded ${saved.name} (${saved.length() / 1024 / 1024}MB). Install prompt opened — user must confirm."
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // search_contacts
        tools.add(AgentTool(
            name = "search_contacts", description = "Search contacts by name. Args: query (name to search)", riskLevel = 2, category = "phone"
        ) { args, ctx ->
            val query = args["query"] as? String ?: return@AgentTool "Error: no query"
            try {
                val results = mutableListOf<String>()
                ctx.contentResolver.query(
                    android.provider.ContactsContract.Contacts.CONTENT_URI,
                    arrayOf(
                        android.provider.ContactsContract.Contacts._ID,
                        android.provider.ContactsContract.Contacts.DISPLAY_NAME,
                        android.provider.ContactsContract.Contacts.PHOTO_ID
                    ),
                    "${android.provider.ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",
                    arrayOf("%$query%"), null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(1) ?: continue
                        results.add(name)
                        if (results.size >= 20) break
                    }
                }
                if (results.isEmpty()) "No contacts found matching '$query'"
                else "Found ${results.size} contacts:\n" + results.joinToString("\n") { "- $it" }
            } catch (e: SecurityException) {
                "NEED_PERMISSION:storage|Contacts permission is required"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // get_alarms
        tools.add(AgentTool(
            name = "get_alarms", description = "List set alarms", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val intent = android.content.Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                "Opened alarm app to show alarms"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // get_step_count
        tools.add(AgentTool(
            name = "get_step_count", description = "Get today's step count (requires fitness sensor)", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
                val stepSensor = sm.getDefaultSensor(android.hardware.Sensor.TYPE_STEP_COUNTER)
                    ?: return@AgentTool "Error: no step counter sensor available"
                "Step sensor available: ${stepSensor.name}. Note: real-time step reading requires a foreground service."
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // get_screen_state
        tools.add(AgentTool(
            name = "get_screen_state", description = "Get screen state: brightness, rotation, timeout", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val brightness = android.provider.Settings.System.getInt(ctx.contentResolver,
                    android.provider.Settings.System.SCREEN_BRIGHTNESS, -1)
                val timeout = android.provider.Settings.System.getInt(ctx.contentResolver,
                    android.provider.Settings.System.SCREEN_OFF_TIMEOUT, -1)
                val rotation = android.provider.Settings.System.getInt(ctx.contentResolver,
                    android.provider.Settings.System.ACCELEROMETER_ROTATION, -1)
                "Brightness: $brightness/255, Screen timeout: ${timeout/1000}s, Auto-rotate: ${if (rotation == 1) "on" else "off"}"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // set_screen_timeout
        tools.add(AgentTool(
            name = "set_screen_timeout", description = "Set screen timeout. Args: seconds (e.g. 30, 60, 300)", riskLevel = 2, category = "device"
        ) { args, ctx ->
            val seconds = (args["seconds"] as? Number)?.toInt()?.coerceIn(15, 1800) ?: return@AgentTool "Error: no seconds"
            try {
                android.provider.Settings.System.putInt(ctx.contentResolver,
                    android.provider.Settings.System.SCREEN_OFF_TIMEOUT, seconds * 1000)
                "Screen timeout set to ${seconds}s"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // get_installed_size
        tools.add(AgentTool(
            name = "get_storage_usage", description = "Get storage usage by type", riskLevel = 1, category = "device"
        ) { _, ctx ->
            try {
                val stat = android.os.StatFs(ctx.filesDir.path)
                val total = stat.blockCountLong * stat.blockSizeLong
                val free = stat.availableBlocksLong * stat.blockSizeLong
                val used = total - free
                val df = java.text.DecimalFormat("#.##")
                buildString {
                    appendLine("Total: ${df.format(total / 1024.0 / 1024 / 1024)} GB")
                    appendLine("Used: ${df.format(used / 1024.0 / 1024 / 1024)} GB")
                    appendLine("Free: ${df.format(free / 1024.0 / 1024 / 1024)} GB")
                    appendLine("Usage: ${df.format(used.toDouble() / total * 100)}%")
                }
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // execute_phone_action - AutoGLM phone control (hidden unless master switch is on)
        if (PHONE_AGENT_ENABLED) {
            tools.add(AgentTool(
                name = "execute_phone_action", description = "Execute a phone action using AutoGLM (tap, swipe, type, open app, etc.)", riskLevel = 3, category = "phone"
            ) { args, ctx ->
                val instruction = args["instruction"] as? String ?: return@AgentTool "Error: no instruction"
                loadZhipuKeyFromPrefs(ctx)
                val apiKey = zhipuApiKey.ifBlank { return@AgentTool "Error: no zhipu API key configured. Please set it in Phone Agent settings." }
                if (!MiMoAccessibilityService.isRunning) {
                    return@AgentTool "NEED_PERMISSION:accessibility|Accessibility service is not enabled — phone control requires it"
                }
                try {
                    val autoGLM = AutoGLMService()
                    autoGLM.updateApiKey(apiKey)
                    val adb = AdbExecutor()
                    if (!ScreenCaptureService.hasPermission()) {
                        return@AgentTool "NEED_PERMISSION:projection|Screen capture (MediaProjection) permission is required to see the screen"
                    }
                    val screenshot = adb.captureScreen(ctx)
                    if (screenshot != null) {
                        val action = kotlinx.coroutines.runBlocking {
                            autoGLM.execute(screenshot, instruction)
                        }
                        if (action != null) {
                            val result = when (action.type) {
                                "tap" -> { adb.tap(action.x ?: 0, action.y ?: 0); "Tapped at (${action.x}, ${action.y})" }
                                "swipe" -> { adb.swipe(action.x1 ?: 0, action.y1 ?: 0, action.x2 ?: 0, action.y2 ?: 0); "Swiped" }
                                "type" -> { adb.inputText(action.text ?: ""); "Typed: ${action.text}" }
                                "back" -> { adb.pressBack(); "Pressed back" }
                                "home" -> { adb.pressHome(); "Pressed home" }
                                "launch" -> { adb.launchApp(action.package_name ?: ""); "Launched ${action.package_name}" }
                                "done" -> "Action completed"
                                "take_over" -> "Waiting for user to complete action"
                                else -> "Unknown action: ${action.type}"
                            }
                            "Action executed: $result"
                        } else {
                            "Error: failed to get action from AI"
                        }
                    } else {
                        "Error: failed to capture screen"
                    }
                } catch (e: Exception) {
                    "Error: ${e.message}"
                }
            })
        }

        // run_adb — 优先走无线调试真 ADB（shell 权限），未配对回退 App 沙箱 sh
        tools.add(AgentTool(
            name = "run_adb", description = "Execute a shell command via wireless-debugging ADB (real shell privileges). Falls back to app-sandbox shell if ADB is not connected", riskLevel = 5, category = "system"
        ) { args, _ ->
            val command = args["command"] as? String ?: return@AgentTool "Error: no command"
            try {
                val adbResult = com.mimo.app.adb.AdbManager.executeShell(command)
                if (adbResult != null) {
                    adbResult.ifBlank { "Command executed (no output)" }
                } else {
                    val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
                    val output = process.inputStream.bufferedReader().readText()
                    val error = process.errorStream.bufferedReader().readText()
                    process.waitFor()
                    if (error.isNotBlank()) "STDERR: $error\nSTDOUT: $output"
                    else output.ifBlank { "Command executed (no output)" }
                }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // get_device_info
        tools.add(AgentTool(
            name = "get_device_info", description = "Get device information", riskLevel = 1, category = "system"
        ) { _, ctx ->
            buildString {
                append("Model: ${android.os.Build.MODEL}\n")
                append("Brand: ${android.os.Build.BRAND}\n")
                append("Android: ${android.os.Build.VERSION.RELEASE}\n")
                append("SDK: ${android.os.Build.VERSION.SDK_INT}\n")
                append("Battery: ${getBatteryLevel(ctx)}%\n")
                append("Free space: ${Environment.getExternalStorageDirectory().freeSpace / 1024 / 1024}MB")
            }
        })

        // fetch_url
        tools.add(AgentTool(
            name = "fetch_url", description = "Fetch and read a web page content (returns text)", riskLevel = 2, category = "network"
        ) { args, _ ->
            val url = args["url"] as? String ?: return@AgentTool "Error: no url"
            val maxLen = (args["max_length"] as? Number)?.toInt() ?: 5000
            try {
                val client = okhttp3.OkHttpClient.Builder()
                    .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .build()
                val request = okhttp3.Request.Builder().url(url)
                    .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android) MiMoAgent/1.0")
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val html = response.body?.string() ?: return@AgentTool "Error: empty response"
                    val text = html
                        .replace(Regex("<script[\\s\\S]*?</script>"), "")
                        .replace(Regex("<style[\\s\\S]*?</style>"), "")
                        .replace(Regex("<[^>]+>"), " ")
                        .replace(Regex("\\s+"), " ")
                        .trim()
                    if (text.length > maxLen) text.take(maxLen) + "\n...(truncated)" else text
                } else {
                    "Error: HTTP ${response.code}"
                }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        })

        // save_skill
        tools.add(AgentTool(
            name = "save_skill", description = "Save a reusable skill/workflow", riskLevel = 2, category = "skill"
        ) { args, _ ->
            val name = args["name"] as? String ?: return@AgentTool "Error: no name"
            val content = args["content"] as? String ?: return@AgentTool "Error: no content"
            val file = File(skillsDir, "$name.md")
            file.writeText(content)
            "Skill '$name' saved"
        })

        // read_skill
        tools.add(AgentTool(
            name = "read_skill", description = "Read a saved skill", riskLevel = 1, category = "skill"
        ) { args, _ ->
            val name = args["name"] as? String ?: return@AgentTool "Error: no name"
            val file = File(skillsDir, "$name.md")
            if (file.exists()) file.readText() else "Error: skill not found"
        })

        // list_skills
        tools.add(AgentTool(
            name = "list_skills", description = "List all saved skills", riskLevel = 1, category = "skill"
        ) { _, _ ->
            skillsDir.listFiles()?.filter { it.extension == "md" }
                ?.joinToString("\n") { it.nameWithoutExtension } ?: "No skills saved"
        })

        // request_permission - ask the user to grant a system permission & jump to Settings
        tools.add(AgentTool(
            name = "request_permission",
            description = "Ask the user to grant a system permission. Use when a needed permission is missing. Args: permission (accessibility|overlay|storage|projection|notification|mic), reason (why it is needed)",
            riskLevel = 1, category = "system"
        ) { args, _ ->
            val permission = (args["permission"] as? String ?: "storage").lowercase()
            val reason = args["reason"] as? String ?: "Required to continue the task"
            "NEED_PERMISSION:$permission|$reason"
        })

        // === Task checklist tools ===
        tools.add(AgentTool(
            name = "add_task",
            description = "Add a task to the checklist. Args: title (task description)",
            riskLevel = 1, category = "task"
        ) { args, _ ->
            val title = args["title"] as? String ?: return@AgentTool "Error: no title"
            val task = taskManager.addTask(title)
            "Added ${task.label}: $title"
        })

        tools.add(AgentTool(
            name = "update_task",
            description = "Update a task's status. Args: id (task number, e.g. 1), status (pending|in_progress|done|cancelled)",
            riskLevel = 1, category = "task"
        ) { args, _ ->
            val id = (args["id"] as? Number)?.toInt() ?: return@AgentTool "Error: no id"
            val status = (args["status"] as? String ?: "").lowercase()
            val s = when (status) {
                "pending" -> CheckTaskStatus.PENDING
                "in_progress" -> CheckTaskStatus.IN_PROGRESS
                "done" -> CheckTaskStatus.DONE
                "cancelled" -> CheckTaskStatus.CANCELLED
                else -> return@AgentTool "Error: status must be pending|in_progress|done|cancelled"
            }
            taskManager.updateStatus(id, s)
            "T$id → $status"
        })

        tools.add(AgentTool(
            name = "strike_task",
            description = "Remove a task from the checklist (marks it as failed). Args: id (task number)",
            riskLevel = 1, category = "task"
        ) { args, _ ->
            val id = (args["id"] as? Number)?.toInt() ?: return@AgentTool "Error: no id"
            taskManager.strikeTask(id)
            "Struck T$id"
        })

        // === Script execution ===

        // run_shell
        tools.add(AgentTool(
            name = "run_shell", description = "Execute a shell command (no root). Args: command, timeout (optional seconds, default 30)", riskLevel = 3, category = "system"
        ) { args, _ ->
            val cmd = args["command"] as? String ?: return@AgentTool "Error: no command"
            val timeout = (args["timeout"] as? Number)?.toLong() ?: 30L
            try {
                val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
                val stdout = StringBuilder()
                val stderr = StringBuilder()
                val outThread = Thread { process.inputStream.bufferedReader().use { r -> r.forEachLine { stdout.appendLine(it) } } }
                val errThread = Thread { process.errorStream.bufferedReader().use { r -> r.forEachLine { stderr.appendLine(it) } } }
                outThread.start(); errThread.start()
                val finished = process.waitFor(timeout.coerceIn(1, 300), java.util.concurrent.TimeUnit.SECONDS)
                if (!finished) { process.destroyForcibly(); return@AgentTool "Error: timeout after ${timeout}s" }
                outThread.join(2000); errThread.join(2000)
                val exitCode = process.exitValue()
                buildString {
                    if (exitCode != 0) appendLine("Exit code: $exitCode")
                    if (stdout.isNotBlank()) appendLine(stdout.toString().trimEnd())
                    if (stderr.isNotBlank()) appendLine("STDERR: ${stderr.toString().trimEnd()}")
                    if (stdout.isBlank() && stderr.isBlank()) appendLine("(no output)")
                }.take(8000)
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // run_python — uses Termux if available
        tools.add(AgentTool(
            name = "run_python", description = "Run a Python script. Args: code (Python source) or path (path to .py file). Requires Termux with Python installed.", riskLevel = 3, category = "system"
        ) { args, ctx ->
            val code = args["code"] as? String
            val path = args["path"] as? String
            if (code.isNullOrBlank() && path.isNullOrBlank()) return@AgentTool "Error: provide code or path"

            // Check if Termux is installed
            val termuxPkg = "com.termux"
            val hasTermux = try { ctx.packageManager.getPackageInfo(termuxPkg, 0); true } catch (_: Exception) { false }
            if (!hasTermux) return@AgentTool "Error: Termux not installed. Install Termux from F-Droid, then: pkg install python. Alternatively use run_shell for shell commands."

            try {
                // Write code to a temp file in workspace
                val scriptFile = if (path != null) resolvePath(path) else {
                    val f = java.io.File(workspaceDir, "_agent_script.py")
                    f.writeText(code!!)
                    f
                }
                if (!validatePath(scriptFile)) return@AgentTool "Error: access denied"
                if (!scriptFile.exists()) return@AgentTool "Error: script not found"

                // Run via Termux
                val termuxFiles = ctx.getExternalFilesDir(null)?.parentFile?.parentFile?.parentFile
                val termuxBin = java.io.File(termuxFiles, "com.termux/files/usr/bin/python3")
                val pythonBin = if (termuxBin.exists()) termuxBin.absolutePath else "python3"

                val process = ProcessBuilder(pythonBin, scriptFile.absolutePath)
                    .directory(java.io.File(ctx.getExternalFilesDir(null)?.parentFile?.parentFile?.parentFile,
                        "com.termux/files/home"))
                    .redirectErrorStream(true)
                    .start()
                val output = StringBuilder()
                val reader = Thread { process.inputStream.bufferedReader().use { r -> r.forEachLine { output.appendLine(it) } } }
                reader.start()
                val finished = process.waitFor(60, java.util.concurrent.TimeUnit.SECONDS)
                if (!finished) { process.destroyForcibly(); return@AgentTool "Error: Python timeout after 60s" }
                reader.join(2000)
                "Exit: ${process.exitValue()}\n${output.toString().trimEnd().take(8000)}"
            } catch (e: Exception) { "Error: ${e.message}" }
        })

        // run_node — uses Termux Node.js if available
        tools.add(AgentTool(
            name = "run_node", description = "Run a Node.js script. Args: code or path. Requires Termux with Node installed.", riskLevel = 3, category = "system"
        ) { args, ctx ->
            val code = args["code"] as? String
            val path = args["path"] as? String
            if (code.isNullOrBlank() && path.isNullOrBlank()) return@AgentTool "Error: provide code or path"

            val hasTermux = try { ctx.packageManager.getPackageInfo("com.termux", 0); true } catch (_: Exception) { false }
            if (!hasTermux) return@AgentTool "Error: Termux not installed. Install Termux, then: pkg install nodejs"

            try {
                val scriptFile = if (path != null) resolvePath(path) else {
                    val f = java.io.File(workspaceDir, "_agent_script.js")
                    f.writeText(code!!)
                    f
                }
                if (!validatePath(scriptFile)) return@AgentTool "Error: access denied"

                val termuxFiles = ctx.getExternalFilesDir(null)?.parentFile?.parentFile?.parentFile
                val nodeBin = java.io.File(termuxFiles, "com.termux/files/usr/bin/node")
                val node = if (nodeBin.exists()) nodeBin.absolutePath else "node"

                val process = ProcessBuilder(node, scriptFile.absolutePath)
                    .redirectErrorStream(true)
                    .start()
                val output = StringBuilder()
                val reader = Thread { process.inputStream.bufferedReader().use { r -> r.forEachLine { output.appendLine(it) } } }
                reader.start()
                val finished = process.waitFor(60, java.util.concurrent.TimeUnit.SECONDS)
                if (!finished) { process.destroyForcibly(); return@AgentTool "Error: Node timeout after 60s" }
                reader.join(2000)
                "Exit: ${process.exitValue()}\n${output.toString().trimEnd().take(8000)}"
            } catch (e: Exception) { "Error: ${e.message}" }
        })
    }

    suspend fun executeTool(toolName: String, args: Map<String, Any>, mode: Int): String {
        val tool = tools.find { it.name == toolName }
            ?: return "Error: unknown tool '$toolName'"
        if (!tool.enabled) {
            return "BLOCKED: Tool '$toolName' is disabled"
        }

        val alwaysConfirm = tool.requireConfirmation || confirmTools.contains(toolName)

        val needUserConfirm = when (mode) {
            MODE_ASK_ALL -> true
            MODE_AUTO -> false
            MODE_AI_APPROVE -> {
                // AI reviews first; on deny (or AI failure) fall back to user approval
                val aiApproved = aiApproveTool(tool, args)
                if (aiApproved == true) false else true
            }
            else -> { // MODE_DEFAULT
                // per-tool confirmation flags, or high-risk (4-5) tools
                alwaysConfirm || tool.riskLevel > 3
            }
        }

        if (needUserConfirm) {
            val confirmed = requestConfirmation(toolName, args, tool.description)
            if (!confirmed) return "DENIED: User denied tool '$toolName'"
        }
        return withContext(Dispatchers.IO) {
            try {
                tool.execute(args, context)
            } catch (e: Exception) {
                "Error executing $toolName: ${e.message}"
            }
        }
    }

    /**
     * AI approval: asks the model whether this tool call is safe to run.
     * true = approved, false = denied, null = AI unavailable (caller falls back to user).
     */
    private suspend fun aiApproveTool(tool: AgentTool, args: Map<String, Any>): Boolean? {
        return try {
            val argsJson = try { gson.toJson(args) } catch (_: Exception) { "{}" }
            val prompt = """You are a permission reviewer for an AI phone assistant.
Decide whether this tool call should be auto-approved without asking the user.

Tool: ${tool.name} (risk ${tool.riskLevel}/5)
Description: ${tool.description}
Arguments: $argsJson

Rules:
- Approve read-only or low-impact actions (reading files, listing, device info, fetching URLs).
- Deny destructive or sensitive actions (delete, overwrite outside workspace, shell commands, payments, privacy data).
- Deny if arguments look harmful or ambiguous.

Reply with EXACTLY one word: APPROVE or DENY."""
            val request = com.mimo.app.data.model.ChatRequest(
                model = "mimo-v2.6-flash",
                messages = listOf(com.mimo.app.data.model.Message(role = "user", content = prompt)),
                maxCompletionTokens = 8,
                temperature = 0f,
                stream = false,
                thinking = com.mimo.app.data.model.ThinkingConfig(type = "disabled")
            )
            val response = apiService.chatCompletionStructured(request)
            val text = response.choices.firstOrNull()?.message?.content?.toString()?.trim()?.uppercase() ?: return null
            when {
                text.contains("APPROVE") -> true
                text.contains("DENY") -> false
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun requestConfirmation(toolName: String, args: Map<String, Any>, description: String): Boolean {
        return suspendCancellableCoroutine { continuation ->
            pendingConfirmation = PendingConfirmation(toolName, args, description, continuation)
            onConfirmationRequested?.invoke(toolName, args, description)
            continuation.invokeOnCancellation {
                pendingConfirmation = null
            }
        }
    }

    fun approvePendingConfirmation() {
        val pending = pendingConfirmation ?: return
        pendingConfirmation = null
        pending.continuation.resume(true)
    }

    fun denyPendingConfirmation() {
        val pending = pendingConfirmation ?: return
        pendingConfirmation = null
        pending.continuation.resume(false)
    }

    fun getToolPermissions(): List<ToolPermission> {
        return tools.map { tool ->
            ToolPermission(
                toolName = tool.name,
                enabled = !disabledTools.contains(tool.name),
                requireConfirmation = confirmTools.contains(tool.name) || tool.requireConfirmation
            )
        }
    }

    fun updateToolPermission(toolName: String, enabled: Boolean?, requireConfirmation: Boolean?) {
        tools.find { it.name == toolName }?.let { tool ->
            if (enabled != null) {
                tool.enabled = enabled
                if (!enabled) disabledTools.add(toolName) else disabledTools.remove(toolName)
            }
            if (requireConfirmation != null) {
                tool.requireConfirmation = requireConfirmation
                if (requireConfirmation) confirmTools.add(toolName) else confirmTools.remove(toolName)
            }
        }
    }

    fun getToolsDescription(): String {
        return tools.filter { it.enabled }.joinToString("\n") { "- ${it.name} (risk:${it.riskLevel}): ${it.description}" }
    }

    fun getToolsByCategory(): Map<String, List<AgentTool>> {
        return tools.groupBy { it.category }
    }

    fun saveWorkspaceFile(name: String, content: String): File {
        val file = File(outputDir, name)
        file.writeText(content)
        return file
    }

    fun addScheduledTask(prompt: String): AgentTask {
        val task = AgentTask(prompt = prompt)
        scheduledTasks.add(task)
        return task
    }

    private fun getBatteryLevel(ctx: Context): Int {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        return bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
}
