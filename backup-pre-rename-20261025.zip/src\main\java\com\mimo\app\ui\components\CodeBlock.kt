package com.mimo.app.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun CodeBlock(
    code: String,
    language: String = "",
    isDarkTheme: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    val codeBg = if (isDarkTheme) Color(0xFF2A2A2A) else Color(0xFFECECEC)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(codeBg)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (language.isNotBlank()) {
                Text(
                    text = language,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Spacer(modifier = Modifier)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                // Copy
                TextButton(
                    onClick = {
                        ClipboardHelper.copyWithToast(context, code, label = "code")
                        copied = true
                    },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(11.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(if (copied) "已复制" else "复制", fontSize = 10.sp)
                }

                // Save
                TextButton(
                    onClick = {
                        try {
                            val dir = File(context.filesDir, "workspace")
                            if (!dir.exists()) dir.mkdirs()
                            val ext = when (language.lowercase()) {
                                "kotlin", "kt" -> "kt"
                                "python", "py" -> "py"
                                "javascript", "js" -> "js"
                                "typescript", "ts" -> "ts"
                                "java" -> "java"
                                "c" -> "c"
                                "cpp", "c++" -> "cpp"
                                "csharp", "c#" -> "cs"
                                "go" -> "go"
                                "rust", "rs" -> "rs"
                                "swift" -> "swift"
                                "shell", "bash", "sh" -> "sh"
                                "sql" -> "sql"
                                "html" -> "html"
                                "css" -> "css"
                                "json" -> "json"
                                "yaml", "yml" -> "yaml"
                                "toml" -> "toml"
                                "xml" -> "xml"
                                else -> "txt"
                            }
                            val fileName = "code_${System.currentTimeMillis()}.$ext"
                            File(dir, fileName).writeText(code)
                            android.widget.Toast.makeText(context, "已保存到 workspace/$fileName", android.widget.Toast.LENGTH_SHORT).show()
                            saved = true
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "保存失败: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(11.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(if (saved) "已保存" else "保存", fontSize = 10.sp)
                }

                // View in new activity
                TextButton(
                    onClick = {
                        try {
                            val dir = File(context.filesDir, "workspace")
                            if (!dir.exists()) dir.mkdirs()
                            val ext = when (language.lowercase()) {
                                "kotlin", "kt" -> "kt"
                                "python", "py" -> "py"
                                "javascript", "js" -> "js"
                                else -> "txt"
                            }
                            val fileName = "view_${System.currentTimeMillis()}.$ext"
                            val file = File(dir, fileName)
                            file.writeText(code)
                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                context, "${context.packageName}.fileprovider", file
                            )
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "text/plain")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "无法打开: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(11.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("查看", fontSize = 10.sp)
                }
            }
        }

        HorizontalDivider(
            thickness = 0.5.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
        )

        // Code content
        Text(
            text = code,
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
