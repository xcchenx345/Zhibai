package com.mimo.app.ui.components

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Parse "#AARRGGBB" or "#RRGGBB" hex string to Color. */
internal fun parseHexColor(hex: String): Color? {
    val s = hex.trim().removePrefix("#")
    return try {
        when (s.length) {
            6 -> Color(android.graphics.Color.parseColor("#FF$s"))
            8 -> Color(android.graphics.Color.parseColor("#$s"))
            else -> null
        }
    } catch (_: Exception) { null }
}

/**
 * Floating frosted-glass container for the chat input area.
 *
 * Simple translucent tint + border + shadow. The blur effect is applied
 * to the message list via Modifier.blur in ChatScreen.
 */
@Composable
fun GlassInputBar(
    isGlass: Boolean,
    blurColorHex: String,
    shadowEnabled: Boolean,
    cornerRadiusDp: Int,
    squircle: Boolean,
    isTyping: Boolean,
    blurIntensity: Int = 50,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val isDark = isSystemInDarkTheme()

    if (!isGlass) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shadowElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface
        ) {
            content()
        }
        return
    }

    val tint = parseHexColor(blurColorHex)
        ?: if (isDark) Color(0x991E1E1E) else Color(0x99FFFFFF)

    val intensityAlpha = (blurIntensity / 100f) * 0.45f + 0.08f
    val targetAlpha = if (isTyping) (intensityAlpha + 0.25f).coerceAtMost(0.95f)
                      else intensityAlpha
    val animatedTint by animateColorAsState(
        targetValue = tint.copy(alpha = targetAlpha),
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "glassTint"
    )

    val shape: Shape = if (squircle) {
        SuperellipseShape(cornerRadius = cornerRadiusDp.dp, exponent = 3f)
    } else {
        RoundedCornerShape(cornerRadiusDp.dp)
    }

    val elevation by animateFloatAsState(
        targetValue = if (shadowEnabled) 18f else 0f,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "glassElevation"
    )

    // No bright border — heavier shadow for depth instead
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .then(
                if (shadowEnabled && elevation > 0f) {
                    Modifier.shadow(
                        elevation = elevation.dp,
                        shape = shape,
                        clip = false,
                        ambientColor = Color.Black.copy(alpha = 0.45f),
                        spotColor = Color.Black.copy(alpha = 0.45f)
                    )
                } else Modifier
            )
            .clip(shape)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = animatedTint,
            content = content
        )
    }
}
