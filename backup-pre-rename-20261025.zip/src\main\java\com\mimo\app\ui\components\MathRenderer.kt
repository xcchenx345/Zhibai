package com.mimo.app.ui.components

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathRenderer(
    content: String,
    modifier: Modifier = Modifier,
    studyMode: Boolean = false
) {
    val htmlContent = markdownToSimpleHtml(content)

    // Study mode: warm paper bg + handwriting-ish serif for English, KaiTi-style for CJK.
    // Normal mode: transparent bg, system sans.
    val bodyFont = if (studyMode)
        "'Georgia', 'Times New Roman', 'STKaiti', 'KaiTi', 'Kaiti SC', serif"
    else
        "-apple-system, BlinkMacSystemFont, sans-serif"
    val bodyBg = if (studyMode) "#f7f2e9" else "transparent"
    val bodyColor = if (studyMode) "#2c2416" else "#1a1a1a"

    val html = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body {
            max-width: 100%;
            overflow-x: auto;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        .katex-display {
            overflow-x: auto;
            overflow-y: hidden;
            padding: 4px 0;
        }
        body {
            font-family: $bodyFont;
            padding: 8px 12px;
            background: $bodyBg;
            font-size: 15px;
            line-height: 1.75;
            color: $bodyColor;
        }
        p { margin: 0.4em 0; }
        strong { font-weight: 600; }
        em { font-style: italic; }
        code {
            background: rgba(0,0,0,0.06);
            padding: 1px 4px;
            border-radius: 3px;
            font-size: 0.9em;
            word-break: break-all;
        }
        pre {
            background: rgba(0,0,0,0.04);
            padding: 8px 12px;
            border-radius: 6px;
            overflow-x: auto;
            max-width: 100%;
            margin: 0.5em 0;
        }
        pre code { background: none; padding: 0; word-break: normal; }
        h1, h2, h3 { font-weight: 600; margin: 0.6em 0 0.3em; }
        h1 { font-size: 1.3em; }
        h2 { font-size: 1.15em; }
        h3 { font-size: 1.05em; }
        ul, ol { padding-left: 1.5em; margin: 0.3em 0; }
        li { margin: 0.15em 0; }
        blockquote {
            border-left: 3px solid rgba(0,0,0,0.2);
            padding-left: 12px;
            color: rgba(0,0,0,0.6);
            margin: 0.5em 0;
        }
        hr { border: none; border-top: 1px solid rgba(0,0,0,0.15); margin: 0.8em 0; }
        /* KaTeX: never overflow — display math scales down or wraps */
        .katex { font-size: 1.05em; max-width: 100%; }
        .katex-display {
            margin: 0.6em 0;
            overflow-x: auto;
            overflow-y: hidden;
            max-width: 100%;
            padding: 2px 0;
            -webkit-overflow-scrolling: touch;
        }
        .katex-display > .katex {
            text-align: left;
            max-width: 100%;
            white-space: normal;
            word-break: break-word;
        }
        /* Long inline math won't push layout wide */
        .katex .mord, .katex .mbin, .katex .mrel, .katex .mopen, .katex .mclose, .katex .mpunct {
            max-width: 100%;
        }
    </style>
</head>
<body>
    $htmlContent
    <script>
        renderMathInElement(document.body, {
            delimiters: [
                {left: '$$', right: '$$', display: true},
                {left: '$', right: '$', display: false},
                {left: '\\[', right: '\\]', display: true},
                {left: '\\(', right: '\\)', display: false}
            ],
            throwOnError: false,
            // Strict: malformed math renders as raw text rather than exploding layout
            errorColor: '#cc0000'
        });
        // Post-render: clamp any display math wider than viewport
        document.querySelectorAll('.katex-display').forEach(function(el) {
            if (el.scrollWidth > el.clientWidth) {
                el.style.overflowX = 'auto';
            }
        });
    </script>
</body>
</html>
    """.trimIndent()

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                webViewClient = WebViewClient()
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                setBackgroundColor(0)
                loadDataWithBaseURL("https://mimo.app", html, "text/html", "UTF-8", null)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL("https://mimo.app", html, "text/html", "UTF-8", null)
        },
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
    )
}

private fun markdownToSimpleHtml(md: String): String {
    val lines = md.lines()
    val result = StringBuilder()
    var inCodeBlock = false
    var inList = false

    for (line in lines) {
        val trimmed = line.trim()

        if (trimmed.startsWith("```")) {
            if (inCodeBlock) {
                result.append("</code></pre>")
                inCodeBlock = false
            } else {
                if (inList) { result.append("</ul>"); inList = false }
                result.append("<pre><code>")
                inCodeBlock = true
            }
            continue
        }
        if (inCodeBlock) {
            result.append(escapeHtml(line)).append("\n")
            continue
        }

        if (trimmed.isBlank()) {
            if (inList) { result.append("</ul>"); inList = false }
            continue
        }

        when {
            trimmed.startsWith("### ") -> { if (inList) { result.append("</ul>"); inList = false }; result.append("<h3>${inlineHtml(trimmed.removePrefix("### "))}</h3>"); continue }
            trimmed.startsWith("## ") -> { if (inList) { result.append("</ul>"); inList = false }; result.append("<h2>${inlineHtml(trimmed.removePrefix("## "))}</h2>"); continue }
            trimmed.startsWith("# ") -> { if (inList) { result.append("</ul>"); inList = false }; result.append("<h1>${inlineHtml(trimmed.removePrefix("# "))}</h1>"); continue }
        }

        if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
            if (!inList) { result.append("<ul>"); inList = true }
            result.append("<li>${inlineHtml(trimmed.removePrefix("- ").removePrefix("* "))}</li>")
            continue
        }

        if (trimmed.matches(Regex("^\\d+\\. .*"))) {
            if (!inList) { result.append("<ol>"); inList = true }
            result.append("<li>${inlineHtml(trimmed.replaceFirst(Regex("^\\d+\\. "), ""))}</li>")
            continue
        }

        if (inList) { result.append("</ul>"); inList = false }

        if (trimmed == "---" || trimmed == "***" || trimmed == "___") {
            result.append("<hr>")
            continue
        }

        if (trimmed.startsWith("> ")) {
            result.append("<blockquote>${inlineHtml(trimmed.removePrefix("> "))}</blockquote>")
            continue
        }

        result.append("<p>${inlineHtml(trimmed)}</p>")
    }

    if (inList) result.append("</ul>")
    if (inCodeBlock) result.append("</code></pre>")

    return result.toString()
}

private fun inlineHtml(text: String): String {
    return escapeHtml(text)
        .replace(Regex("\\*\\*(.+?)\\*\\*"), "<strong>$1</strong>")
        .replace(Regex("\\*(.+?)\\*"), "<em>$1</em>")
        .replace(Regex("`([^`]+)`"), "<code>$1</code>")
}

private fun escapeHtml(text: String): String {
    return text
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
}
