package com.mimo.app.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mimo.app.data.api.MiMoApiService
import com.mimo.app.data.api.StreamChunk
import com.mimo.app.data.api.TTSService
import com.mimo.app.data.api.filterForSpeech
import com.mimo.app.data.model.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import java.io.ByteArrayOutputStream
import java.io.File

private val Application.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mimo_settings")

/** One speed sample: t = seconds since stream start, think/answer in chars per second. */
data class SpeedPoint(val t: Float, val think: Float, val answer: Float)

data class SpeedStats(
    val points: List<SpeedPoint> = emptyList(),
    val currentTotal: Float = 0f,
    val currentThink: Float = 0f,
    val currentAnswer: Float = 0f,
    val peakTotal: Float = 0f,
    val elapsedSec: Float = 0f,
    val finished: Boolean = false,
    /** ms from send to first content token; -1 = not yet */
    val firstTokenMs: Long = -1L,
    /** index where reasoning stopped / content began (chart join point) */
    val thinkEndT: Float = -1f
) {
    val avgTotal: Float get() = if (points.isEmpty()) 0f else points.map { it.think + it.answer }.average().toFloat()
    val avgThink: Float get() = if (points.isEmpty()) 0f else points.map { it.think }.average().toFloat()
    val avgAnswer: Float get() = if (points.isEmpty()) 0f else points.map { it.answer }.average().toFloat()
}

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val apiService = MiMoApiService()
    private val agentChatService = MiMoApiService()
    private val ttsService = TTSService()
    private val islandService = com.mimo.app.data.api.IslandNotificationService(application)
    private val context = application

    private val API_KEY = stringPreferencesKey("api_key")
    private val TTS_VOICE_KEY = stringPreferencesKey("tts_voice")
    private val FONT_SIZE_KEY = stringPreferencesKey("font_size")
    private val FORCE_NEW_SESSION_KEY = stringPreferencesKey("force_new_session")
    private val CUSTOM_PROMPT_KEY = stringPreferencesKey("custom_prompt")
    private val AGENT_ENABLED_KEY = stringPreferencesKey("agent_enabled")
    private val AGENT_RISK_KEY = stringPreferencesKey("agent_risk")
    private val AGENT_MODE_KEY = stringPreferencesKey("agent_permission_mode")
    private val AGENT_API_KEY = stringPreferencesKey("agent_api_key")
    private val AGENT_BASE_URL = stringPreferencesKey("agent_base_url")
    private val ZHIPU_API_KEY = stringPreferencesKey("zhipu_api_key")
    private val WORKSPACE_PATH_KEY = stringPreferencesKey("workspace_path")
    private val STRICT_FAITHFUL_KEY = stringPreferencesKey("strict_faithful")
    private val UNLIMITED_ATTACH_KEY = stringPreferencesKey("unlimited_attachments")
    private val SESSIONS_KEY = stringPreferencesKey("sessions")
    private val ONBOARDING_KEY = stringPreferencesKey("onboarding_done")
    private val THINKING_LEVEL_KEY = stringPreferencesKey("thinking_level") // 0-4
    // Floating glass input bar
    private val INPUT_STYLE_KEY = stringPreferencesKey("input_style") // "classic" or "glass"
    private val INPUT_BLUR_COLOR_KEY = stringPreferencesKey("input_blur_color") // hex ARGB string

    // Custom theme colors (empty string = use default)
    private val CUSTOM_FONT_COLOR_KEY = stringPreferencesKey("custom_font_color")
    private val CUSTOM_BG_COLOR_KEY = stringPreferencesKey("custom_bg_color")
    private val CUSTOM_BUBBLE_COLOR_KEY = stringPreferencesKey("custom_bubble_color")
    private val CUSTOM_TEXT_COLOR_KEY = stringPreferencesKey("custom_text_color")

    // Custom font (empty = system default)
    private val CUSTOM_FONT_KEY = stringPreferencesKey("custom_font")
    private val INPUT_SHADOW_KEY = stringPreferencesKey("input_shadow_enabled")
    private val INPUT_CORNER_KEY = stringPreferencesKey("input_corner_radius") // dp int
    private val INPUT_SQUIRCLE_KEY = stringPreferencesKey("input_squircle_enabled") // n=3 superellipse
    private val INPUT_BLUR_INTENSITY_KEY = stringPreferencesKey("input_blur_intensity") // 0-100

    // === Preferences (偏好) ===
    private val PREF_DEFAULT_MODEL = stringPreferencesKey("pref_default_model") // "" = last used
    private val PREF_STARTUP_MODE = stringPreferencesKey("pref_startup_mode") // "new" / "last" / "session"
    private val PREF_STARTUP_SESSION = stringPreferencesKey("pref_startup_session") // session id for "session" mode
    private val PREF_AGENT_THINK_LEVEL = stringPreferencesKey("pref_agent_think_level") // 0-4
    private val PREF_AUTO_COMPRESS = stringPreferencesKey("pref_auto_compress") // "true" / "false"
    private val PREF_AUTO_COMPRESS_THRESHOLD = stringPreferencesKey("pref_auto_compress_threshold") // token count string
    private val PREF_LONG_TERM_MEMORY = stringPreferencesKey("pref_long_term_memory") // "true" / "false"
    private val PREF_MEMORY_AUTO_WRITE = stringPreferencesKey("pref_memory_auto_write") // "true" / "false"
    private val PREF_MODEL_HABIT = stringPreferencesKey("pref_model_habit") // suffix habit, max 10 chars
    private val PREF_SCENARIO = stringPreferencesKey("pref_scenario") // "code" / "work" / "daily" / "study" / ""

    private val gson = com.google.gson.GsonBuilder()
        .serializeNulls()
        .setPrettyPrinting()
        .create()

    private val _sessions = MutableStateFlow<List<ChatSession>>(emptyList())
    val sessions: StateFlow<List<ChatSession>> = _sessions.asStateFlow()

    private val _currentSession = MutableStateFlow<ChatSession?>(null)
    val currentSession: StateFlow<ChatSession?> = _currentSession.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _currentModel = MutableStateFlow("mimo-v2.6-flash")
    val currentModel: StateFlow<String> = _currentModel.asStateFlow()

    // Chat models from GET /models + TTS/ASR as first-class entries
    private val _modelIds = MutableStateFlow(
        listOf(
            "mimo-v2.6-flash", "mimo-v2.6-pro", "mimo-v2.6-pro-ultraspeed",
            "tts-read", "tts-design", "tts-clone", "asr"
        )
    )
    val modelIds: StateFlow<List<String>> = _modelIds.asStateFlow()

    val isTTSMode: Boolean get() = _currentModel.value.startsWith("tts")
    val isASRMode: Boolean get() = _currentModel.value == "asr"
    /** Which TTS sub-model is selected (read / design / clone). */
    val ttsScreenMode: String get() = _currentModel.value.removePrefix("tts-").ifBlank { "read" }

    private val _enableThinking = MutableStateFlow(true)
    val enableThinking: StateFlow<Boolean> = _enableThinking.asStateFlow()
    // 0=Off, 1=Low(1024), 2=Medium(4096), 3=High(8192), 4=MAX(16384)
    private val _thinkingLevel = MutableStateFlow(2)
    val thinkingLevel: StateFlow<Int> = _thinkingLevel.asStateFlow()

    private val _enableSearch = MutableStateFlow(false)
    val enableSearch: StateFlow<Boolean> = _enableSearch.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _apiKeyConfigured = MutableStateFlow(false)
    val apiKeyConfigured: StateFlow<Boolean> = _apiKeyConfigured.asStateFlow()

    /** null = still loading prefs; false = show first-run onboarding. */
    private val _onboardingDone = MutableStateFlow<Boolean?>(null)
    val onboardingDone: StateFlow<Boolean?> = _onboardingDone.asStateFlow()

    // Update preview mode — shows v2.6 changelog as a mini onboarding
    private val _showUpdatePreview = MutableStateFlow(false)
    val showUpdatePreview: StateFlow<Boolean> = _showUpdatePreview.asStateFlow()

    private val _apiKey = MutableStateFlow("")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    // Auto read-aloud
    private val _autoReadAloud = MutableStateFlow(false)
    val autoReadAloud: StateFlow<Boolean> = _autoReadAloud.asStateFlow()

    fun toggleAutoReadAloud() {
        _autoReadAloud.value = !_autoReadAloud.value
        if (!_autoReadAloud.value) stopSpeaking()
    }

    /** Strip markdown/code/tables/etc for TTS — only speak readable prose. */
    fun filterForTTS(text: String): String {
        var t = text
        // Remove code blocks
        t = t.replace(Regex("```[\\s\\S]*?```"), "，代码块已省略，")
        // Remove inline code
        t = t.replace(Regex("`[^`]+`"), "")
        // Remove table rows (lines starting/ending with |)
        t = t.replace(Regex("(?m)^\\|.*\\|\\s*$"), "")
        // Remove markdown headers
        t = t.replace(Regex("(?m)^#{1,6}\\s+"), "")
        // Remove bold/italic markers
        t = t.replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
        t = t.replace(Regex("\\*([^*]+)\\*"), "$1")
        t = t.replace(Regex("__([^_]+)__"), "$1")
        t = t.replace(Regex("_([^_]+)_"), "$1")
        // Remove links, keep text
        t = t.replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1")
        // Remove images
        t = t.replace(Regex("!\\[[^\\]]*\\]\\([^)]+\\)"), "")
        // Remove HTML tags
        t = t.replace(Regex("<[^>]+>"), "")
        // Remove horizontal rules
        t = t.replace(Regex("(?m)^[-*_]{3,}\\s*$"), "")
        // Remove LaTeX
        t = t.replace(Regex("\\$[^$]+\\$"), "")
        t = t.replace(Regex("\\$\\$[\\s\\S]*?\\$\\$"), "")
        // Remove Mermaid/diagram blocks
        t = t.replace(Regex("(?m)^(graph|flowchart|sequenceDiagram|classDiagram|stateDiagram|erDiagram|gantt|pie)\\b.*"), "")
        // Remove markdown list bullets
        t = t.replace(Regex("(?m)^\\s*[-*+]\\s+"), "")
        t = t.replace(Regex("(?m)^\\s*\\d+\\.\\s+"), "")
        // Collapse whitespace
        t = t.replace(Regex("\\s{2,}"), " ").trim()
        return t
    }

    private val _ttsVoice = MutableStateFlow("冰糖")
    val ttsVoice: StateFlow<String> = _ttsVoice.asStateFlow()

    private val _fontSize = MutableStateFlow(15)
    val fontSize: StateFlow<Int> = _fontSize.asStateFlow()

    private val _forceNewSessionOnModelSwitch = MutableStateFlow(true)
    val forceNewSessionOnModelSwitch: StateFlow<Boolean> = _forceNewSessionOnModelSwitch.asStateFlow()

    private val _customPrompt = MutableStateFlow("")
    val customPrompt: StateFlow<String> = _customPrompt.asStateFlow()

    private val _agentEnabled = MutableStateFlow(false)
    val agentEnabled: StateFlow<Boolean> = _agentEnabled.asStateFlow()

    private val _agentPermissionMode = MutableStateFlow(com.mimo.app.agent.AgentEngine.MODE_DEFAULT)
    val agentPermissionMode: StateFlow<Int> = _agentPermissionMode.asStateFlow()

    private val _agentApiKey = MutableStateFlow("")
    val agentApiKey: StateFlow<String> = _agentApiKey.asStateFlow()

    private val _agentBaseUrl = MutableStateFlow("https://token-plan-cn.xiaomimimo.com/v1")
    val agentBaseUrl: StateFlow<String> = _agentBaseUrl.asStateFlow()

    private val _zhipuApiKey = MutableStateFlow("")
    val zhipuApiKey: StateFlow<String> = _zhipuApiKey.asStateFlow()

    private val _workspacePath = MutableStateFlow("")
    val workspacePath: StateFlow<String> = _workspacePath.asStateFlow()

    // Default ON: forbid fabrication, stick strictly to provided content
    private val _strictFaithful = MutableStateFlow(true)
    val strictFaithful: StateFlow<Boolean> = _strictFaithful.asStateFlow()

    // Hidden setting: lift attachment count limits
    private val _unlimitedAttachments = MutableStateFlow(false)
    val unlimitedAttachments: StateFlow<Boolean> = _unlimitedAttachments.asStateFlow()

    // Floating glass input bar prefs
    private val _inputStyle = MutableStateFlow("glass") // "classic" or "glass"
    val inputStyle: StateFlow<String> = _inputStyle.asStateFlow()
    private val _inputBlurColor = MutableStateFlow("#B0FFFFFF") // ARGB hex
    val inputBlurColor: StateFlow<String> = _inputBlurColor.asStateFlow()
    private val _inputShadowEnabled = MutableStateFlow(true)
    val inputShadowEnabled: StateFlow<Boolean> = _inputShadowEnabled.asStateFlow()
    private val _inputCornerRadius = MutableStateFlow(20) // dp
    val inputCornerRadius: StateFlow<Int> = _inputCornerRadius.asStateFlow()
    private val _inputSquircle = MutableStateFlow(false) // n=3 superellipse
    val inputSquircle: StateFlow<Boolean> = _inputSquircle.asStateFlow()
    private val _inputBlurIntensity = MutableStateFlow(50) // 0=transparent, 100=opaque
    val inputBlurIntensity: StateFlow<Int> = _inputBlurIntensity.asStateFlow()

    // Custom theme colors ("" = use default)
    private val _customFontColor = MutableStateFlow("")
    val customFontColor: StateFlow<String> = _customFontColor.asStateFlow()
    private val _customBgColor = MutableStateFlow("")
    val customBgColor: StateFlow<String> = _customBgColor.asStateFlow()
    private val _customBubbleColor = MutableStateFlow("")
    val customBubbleColor: StateFlow<String> = _customBubbleColor.asStateFlow()
    private val _customTextColor = MutableStateFlow("")
    val customTextColor: StateFlow<String> = _customTextColor.asStateFlow()

    // Custom font (file path, "" = system default)
    private val _customFont = MutableStateFlow("")
    val customFont: StateFlow<String> = _customFont.asStateFlow()

    // === Preferences state ===
    private val _prefDefaultModel = MutableStateFlow("")
    val prefDefaultModel: StateFlow<String> = _prefDefaultModel.asStateFlow()
    private val _prefStartupMode = MutableStateFlow("new") // "new" / "last" / "session"
    val prefStartupMode: StateFlow<String> = _prefStartupMode.asStateFlow()
    private val _prefStartupSession = MutableStateFlow("")
    val prefStartupSession: StateFlow<String> = _prefStartupSession.asStateFlow()
    private val _prefAgentThinkLevel = MutableStateFlow(2)
    val prefAgentThinkLevel: StateFlow<Int> = _prefAgentThinkLevel.asStateFlow()
    private val _prefAutoCompress = MutableStateFlow(false)
    val prefAutoCompress: StateFlow<Boolean> = _prefAutoCompress.asStateFlow()
    private val _prefAutoCompressThreshold = MutableStateFlow(800000)
    val prefAutoCompressThreshold: StateFlow<Int> = _prefAutoCompressThreshold.asStateFlow()
    private val _prefLongTermMemory = MutableStateFlow(false)
    val prefLongTermMemory: StateFlow<Boolean> = _prefLongTermMemory.asStateFlow()
    private val _prefMemoryAutoWrite = MutableStateFlow(false)
    val prefMemoryAutoWrite: StateFlow<Boolean> = _prefMemoryAutoWrite.asStateFlow()
    private val _prefModelHabit = MutableStateFlow("")
    val prefModelHabit: StateFlow<String> = _prefModelHabit.asStateFlow()
    private val _prefScenario = MutableStateFlow("")
    val prefScenario: StateFlow<String> = _prefScenario.asStateFlow()
    // Long-term memory content (from MEMORY.md)
    private val _memoryContent = MutableStateFlow("")
    val memoryContent: StateFlow<String> = _memoryContent.asStateFlow()

    // Token / context management
    companion object {
        const val MAX_CONTEXT_TOKENS = 900_000
        const val COMPRESSION_KEEP_LAST = 10
    }
    private val _estimatedTokens = MutableStateFlow(0)
    val estimatedTokens: StateFlow<Int> = _estimatedTokens.asStateFlow()
    private val _isCompressing = MutableStateFlow(false)
    val isCompressing: StateFlow<Boolean> = _isCompressing.asStateFlow()
    private val _compressionProgress = MutableStateFlow(0f)
    val compressionProgress: StateFlow<Float> = _compressionProgress.asStateFlow()

    /** Rough token estimate: ~3.5 chars/token for CJK-heavy text, ~4 for ASCII. */
    private fun estimateTokens(text: String): Int {
        if (text.isBlank()) return 0
        var cjk = 0
        var other = 0
        for (c in text) {
            if (c.code in 0x4E00..0x9FFF || c.code in 0x3000..0x303F || c.code in 0xFF00..0xFFEF) cjk++
            else other++
        }
        return (cjk / 3 + other / 4 + 1).toInt()
    }

    /** Recalculate estimated tokens for the current session. */
    fun recalcTokens() {
        val session = _currentSession.value ?: return
        var total = 0
        for (msg in session.messages) {
            total += estimateTokens(msg.content)
            total += estimateTokens(msg.reasoningContent)
        }
        _estimatedTokens.value = total
    }

    /** Whether the context limit has been reached. */
    val isContextLimitReached: Boolean get() = _estimatedTokens.value >= MAX_CONTEXT_TOKENS

    /**
     * Compress the conversation:
     * - Send all messages to AI asking for a deep summary
     * - Keep last [COMPRESSION_KEEP_LAST] messages
     * - In Agent mode, also preserve tool_group operation records
     */
    fun compressConversation() {
        val session = _currentSession.value ?: return
        if (_isCompressing.value || session.messages.size <= COMPRESSION_KEEP_LAST + 2) return
        if (_isGenerating.value) return

        _isCompressing.value = true
        _compressionProgress.value = 0f
        _error.value = null

        streamingJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                // Build the full conversation text for summarization
                val allMessages = session.messages.filter { !it.isStreaming }
                val convoText = buildString {
                    for (msg in allMessages) {
                        val role = when (msg.role) {
                            "user" -> "用户"
                            "assistant" -> "AI"
                            "tool" -> "工具结果"
                            "tool_group" -> "操作记录"
                            else -> msg.role
                        }
                        appendLine("[$role]: ${msg.content.take(2000)}")
                        if (msg.reasoningContent.isNotBlank()) {
                            appendLine("[思考]: ${msg.reasoningContent.take(1000)}")
                        }
                    }
                }

                _compressionProgress.value = 0.2f

                // Ask AI to summarize
                val activeApi = getActiveApiService()
                val summaryPrompt = """请深度整理以下对话内容，输出一份结构化摘要，包含：
1. 当前讨论的主题和背景
2. 关键要点和结论
3. 未完成的事项或待办
4. 重要的技术细节或决策

对话内容：
$convoText

请用中文输出摘要，简洁但完整。"""

                _compressionProgress.value = 0.4f

                val request = activeApi.buildRequest(
                    messages = listOf(Message(role = "user", content = summaryPrompt)),
                    model = getApiModel(),
                    thinkingConfig = ThinkingConfig(type = "disabled"),
                    enableSearch = false
                )

                var summary = ""
                activeApi.chatCompletion(request).collect { chunk ->
                    if (chunk is StreamChunk.Data) {
                        summary += chunk.content
                        _compressionProgress.value = 0.4f + 0.5f * (summary.length / 2000f).coerceAtMost(1f)
                    }
                }

                _compressionProgress.value = 0.95f

                // Build compressed session: system summary + last N messages
                val keepLast = allMessages.takeLast(COMPRESSION_KEEP_LAST)
                val compressedMsgs = mutableListOf<ChatMessage>()
                compressedMsgs.add(ChatMessage(
                    role = "assistant",
                    content = "[会话摘要 - 以下是之前对话的深度整理]\n\n$summary"
                ))
                compressedMsgs.addAll(keepLast)

                updateSession(session.copy(messages = compressedMsgs))
                _compressionProgress.value = 1f
                recalcTokens()
            } catch (e: kotlinx.coroutines.CancellationException) {
                // user pressed stop
            } catch (e: Exception) {
                _error.value = "压缩失败: ${e.message}"
            } finally {
                _isCompressing.value = false
            }
        }
    }

    // Agent-detected missing permission → ask user to jump to system Settings
    data class PermissionRequest(val type: String, val reason: String)
    private val _pendingPermission = MutableStateFlow<PermissionRequest?>(null)
    val pendingPermission: StateFlow<PermissionRequest?> = _pendingPermission.asStateFlow()
    // Resumes the suspended agent flow after the user grants (true) or skips (false).
    private var permissionGrant: kotlinx.coroutines.CompletableDeferred<Boolean>? = null

    private val _pendingToolCall = MutableStateFlow<com.mimo.app.agent.ToolCallRequest?>(null)
    val pendingToolCall: StateFlow<com.mimo.app.agent.ToolCallRequest?> = _pendingToolCall.asStateFlow()

    private val _toolExecuting = MutableStateFlow(false)
    val toolExecuting: StateFlow<Boolean> = _toolExecuting.asStateFlow()

    private val _speedStats = MutableStateFlow<SpeedStats?>(null)
    val speedStats: StateFlow<SpeedStats?> = _speedStats.asStateFlow()

    var agentEngine: com.mimo.app.agent.AgentEngine? = null
        private set

    val agentTaskManager = com.mimo.app.agent.AgentTaskManager()

    private var streamingJob: Job? = null
    private var currentAudioTrack: android.media.AudioTrack? = null

    init {
        viewModelScope.launch {
            context.dataStore.data.first().let { prefs ->
                val savedKey = prefs[API_KEY] ?: ""
                if (savedKey.isNotBlank()) {
                    _apiKey.value = savedKey
                    _apiKeyConfigured.value = true
                    apiService.updateApiKey(savedKey)
                    ttsService.updateApiKey(savedKey)
                }
                val savedVoice = prefs[TTS_VOICE_KEY]
                if (!savedVoice.isNullOrBlank()) {
                    _ttsVoice.value = savedVoice
                }
                val savedFontSize = prefs[FONT_SIZE_KEY]
                if (!savedFontSize.isNullOrBlank()) {
                    _fontSize.value = savedFontSize.toIntOrNull() ?: 15
                }
                val savedForceNew = prefs[FORCE_NEW_SESSION_KEY]
                if (!savedForceNew.isNullOrBlank()) {
                    _forceNewSessionOnModelSwitch.value = savedForceNew == "true"
                }
                val savedPrompt = prefs[CUSTOM_PROMPT_KEY]
                if (!savedPrompt.isNullOrBlank()) {
                    _customPrompt.value = savedPrompt
                }
                val savedAgent = prefs[AGENT_ENABLED_KEY]
                if (!savedAgent.isNullOrBlank()) {
                    _agentEnabled.value = savedAgent == "true"
                }
                val savedMode = prefs[AGENT_MODE_KEY]
                if (!savedMode.isNullOrBlank()) {
                    _agentPermissionMode.value = savedMode.toIntOrNull()
                        ?: com.mimo.app.agent.AgentEngine.MODE_DEFAULT
                } else {
                    // Migrate from old 1-5 risk slider
                    val oldRisk = prefs[AGENT_RISK_KEY]?.toIntOrNull()
                    _agentPermissionMode.value = when {
                        oldRisk == null -> com.mimo.app.agent.AgentEngine.MODE_DEFAULT
                        oldRisk <= 1 -> com.mimo.app.agent.AgentEngine.MODE_AUTO
                        oldRisk >= 5 -> com.mimo.app.agent.AgentEngine.MODE_ASK_ALL
                        else -> com.mimo.app.agent.AgentEngine.MODE_DEFAULT
                    }
                }
                val savedAgentKey = prefs[AGENT_API_KEY]
                if (!savedAgentKey.isNullOrBlank()) {
                    _agentApiKey.value = savedAgentKey
                }
                val savedAgentUrl = prefs[AGENT_BASE_URL]
                if (!savedAgentUrl.isNullOrBlank()) {
                    _agentBaseUrl.value = savedAgentUrl
                }
                val savedWorkspace = prefs[WORKSPACE_PATH_KEY]
                if (savedWorkspace != null) {
                    _workspacePath.value = savedWorkspace
                }
                prefs[STRICT_FAITHFUL_KEY]?.let { _strictFaithful.value = it == "true" }
                prefs[UNLIMITED_ATTACH_KEY]?.let { _unlimitedAttachments.value = it == "true" }
                _onboardingDone.value = prefs[ONBOARDING_KEY] == "true"
                prefs[INPUT_STYLE_KEY]?.let { _inputStyle.value = it }
                prefs[INPUT_BLUR_COLOR_KEY]?.let { _inputBlurColor.value = it }
                prefs[INPUT_SHADOW_KEY]?.let { _inputShadowEnabled.value = it == "true" }
                prefs[INPUT_CORNER_KEY]?.let { _inputCornerRadius.value = it.toIntOrNull() ?: 20 }
                prefs[INPUT_SQUIRCLE_KEY]?.let { _inputSquircle.value = it == "true" }
                prefs[INPUT_BLUR_INTENSITY_KEY]?.let { _inputBlurIntensity.value = it.toIntOrNull() ?: 50 }
                prefs[CUSTOM_FONT_COLOR_KEY]?.let { _customFontColor.value = it }
                prefs[CUSTOM_BG_COLOR_KEY]?.let { _customBgColor.value = it }
                prefs[CUSTOM_BUBBLE_COLOR_KEY]?.let { _customBubbleColor.value = it }
                prefs[CUSTOM_TEXT_COLOR_KEY]?.let { _customTextColor.value = it }
                prefs[CUSTOM_FONT_KEY]?.let { _customFont.value = it }
                // Load preferences
                prefs[PREF_DEFAULT_MODEL]?.let { _prefDefaultModel.value = it }
                prefs[PREF_STARTUP_MODE]?.let { _prefStartupMode.value = it }
                prefs[PREF_STARTUP_SESSION]?.let { _prefStartupSession.value = it }
                prefs[PREF_AGENT_THINK_LEVEL]?.let { _prefAgentThinkLevel.value = it.toIntOrNull() ?: 2 }
                prefs[PREF_AUTO_COMPRESS]?.let { _prefAutoCompress.value = it == "true" }
                prefs[PREF_AUTO_COMPRESS_THRESHOLD]?.let { _prefAutoCompressThreshold.value = it.toIntOrNull() ?: 800000 }
                prefs[PREF_LONG_TERM_MEMORY]?.let { _prefLongTermMemory.value = it == "true" }
                prefs[PREF_MEMORY_AUTO_WRITE]?.let { _prefMemoryAutoWrite.value = it == "true" }
                prefs[PREF_MODEL_HABIT]?.let { _prefModelHabit.value = it }
                prefs[PREF_SCENARIO]?.let { _prefScenario.value = it }
                // Load long-term memory file
                if (_prefLongTermMemory.value) loadMemoryFile()
                prefs[THINKING_LEVEL_KEY]?.let {
                    val level = it.toIntOrNull() ?: 2
                    _thinkingLevel.value = level
                    _enableThinking.value = level > 0
                }
                if (_agentEnabled.value) {
                    val key = if (_agentApiKey.value.isNotBlank()) _agentApiKey.value else _apiKey.value
                    val url = if (_agentApiKey.value.isNotBlank()) _agentBaseUrl.value else "https://api.xiaomimimo.com/v1"
                    agentChatService.updateApiKey(key)
                    agentChatService.updateBaseUrl(url)
                    val agentToolService = MiMoApiService()
                    agentToolService.updateApiKey(key)
                    agentToolService.updateBaseUrl(url)
                    agentEngine = createAgentEngine(agentToolService)
                }
                // Load saved sessions into the drawer, but always start on a fresh chat
                val savedSessions = loadSessions()
                if (!savedSessions.isNullOrEmpty()) {
                    _sessions.value = savedSessions
                }
            }
            refreshModelList()
            if (_currentSession.value == null) createNewSession()
        }
    }

    /**
     * Fetch available chat models from GET /models.
     * Keeps only mimo-v* chat models; TTS/ASR stay fixed special modes.
     * On failure the previous/default list is kept.
     */
    fun refreshModelList() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ids = apiService.listModels()
                    .filter { it.startsWith("mimo-v") }
                    .filterNot { it.contains("tts") || it.contains("asr") }
                    .distinct()
                if (ids.isNotEmpty()) {
                    // TTS modes appear as first-class models alongside flash/pro
                    _modelIds.value = ids + listOf("tts-read", "tts-design", "tts-clone")
                    val cur = _currentModel.value
                    if (cur != "asr" && !cur.startsWith("tts")) {
                        val base = cur.removeSuffix("-agent")
                        if (base !in ids && cur !in ids) {
                            ids.firstOrNull()?.let { _currentModel.value = it }
                        }
                    }
                }
            } catch (_: Exception) {
                // keep current list on network failure
            }
        }
    }

    fun completeOnboarding() {
        _onboardingDone.value = true
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[ONBOARDING_KEY] = "true"
            }
        }
    }

    fun resetOnboarding() {
        _onboardingDone.value = false
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs.remove(ONBOARDING_KEY)
            }
        }
    }

    fun showUpdatePreview() {
        _showUpdatePreview.value = true
    }

    fun dismissUpdatePreview() {
        _showUpdatePreview.value = false
    }

    /**
     * Apply personalized content to agent workspace files after onboarding.
     * Overwrites the default templates so IDENTITY / USER / SOUL reflect user prefs.
     */
    fun applyAgentWorkspaceProfile(profile: Map<String, String>) {
        if (profile.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val engine = agentEngine ?: return@launch
                engine.writeWorkspaceFiles(profile)
            } catch (_: Exception) {}
        }
    }

    fun setApiKey(key: String) {
        apiService.updateApiKey(key)
        ttsService.updateApiKey(key)
        _apiKey.value = key
        _apiKeyConfigured.value = key.isNotBlank()
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[API_KEY] = key
            }
        }
    }

    fun setTtsVoice(voice: String) {
        _ttsVoice.value = voice
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[TTS_VOICE_KEY] = voice
            }
        }
    }

    fun setFontSize(size: Int) {
        _fontSize.value = size.coerceIn(12, 24)
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[FONT_SIZE_KEY] = size.toString()
            }
        }
    }

    fun setForceNewSessionOnModelSwitch(enabled: Boolean) {
        _forceNewSessionOnModelSwitch.value = enabled
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[FORCE_NEW_SESSION_KEY] = enabled.toString()
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(context.filesDir, "mimo_sessions.json")
                if (file.exists()) file.delete()
                context.dataStore.edit { it.clear() }
            } catch (_: Exception) {}
        }
    }

    fun setCustomPrompt(prompt: String) {
        _customPrompt.value = prompt
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[CUSTOM_PROMPT_KEY] = prompt
            }
        }
    }

    private fun createAgentEngine(toolService: MiMoApiService): com.mimo.app.agent.AgentEngine {
        return com.mimo.app.agent.AgentEngine(
            context, toolService,
            workspaceOverride = _workspacePath.value.trim(),
            taskManager = agentTaskManager
        ).also {
            it.zhipuApiKey = _zhipuApiKey.value
            // Surface confirmation requests from all permission modes as a UI dialog
            it.onConfirmationRequested = { tool, args, desc ->
                // Not executing yet — waiting for user, so enable the Approve/Deny buttons
                _toolExecuting.value = false
                _pendingToolCall.value = com.mimo.app.agent.ToolCallRequest(
                    tool = tool, args = args, reason = desc,
                    // Plain-language summary of this concrete call, for the user only —
                    // aiApproveTool never receives it, so it can't bias the auto-reviewer.
                    annotation = com.mimo.app.agent.describeToolCall(tool, args)
                )
            }
        }
    }

    fun setAgentEnabled(enabled: Boolean) {
        _agentEnabled.value = enabled
        if (enabled && agentEngine == null) {
            val key = if (_agentApiKey.value.isNotBlank()) _agentApiKey.value else _apiKey.value
            val url = if (_agentApiKey.value.isNotBlank()) _agentBaseUrl.value else "https://api.xiaomimimo.com/v1"
            agentChatService.updateApiKey(key)
            agentChatService.updateBaseUrl(url)
            val agentToolService = MiMoApiService()
            agentToolService.updateApiKey(key)
            agentToolService.updateBaseUrl(url)
            agentEngine = createAgentEngine(agentToolService)
        }
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[AGENT_ENABLED_KEY] = enabled.toString()
            }
        }
    }

    fun setAgentPermissionMode(mode: Int) {
        _agentPermissionMode.value = mode.coerceIn(0, 3)
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[AGENT_MODE_KEY] = mode.coerceIn(0, 3).toString()
            }
        }
    }

    fun setStrictFaithful(enabled: Boolean) {
        _strictFaithful.value = enabled
        viewModelScope.launch {
            context.dataStore.edit { it[STRICT_FAITHFUL_KEY] = enabled.toString() }
        }
    }

    fun setUnlimitedAttachments(enabled: Boolean) {
        _unlimitedAttachments.value = enabled
        viewModelScope.launch {
            context.dataStore.edit { it[UNLIMITED_ATTACH_KEY] = enabled.toString() }
        }
    }

    fun setInputStyle(style: String) {
        _inputStyle.value = style
        viewModelScope.launch { context.dataStore.edit { it[INPUT_STYLE_KEY] = style } }
    }

    fun setInputBlurColor(color: String) {
        _inputBlurColor.value = color
        viewModelScope.launch { context.dataStore.edit { it[INPUT_BLUR_COLOR_KEY] = color } }
    }

    fun setInputShadowEnabled(enabled: Boolean) {
        _inputShadowEnabled.value = enabled
        viewModelScope.launch { context.dataStore.edit { it[INPUT_SHADOW_KEY] = enabled.toString() } }
    }

    fun setInputCornerRadius(dp: Int) {
        _inputCornerRadius.value = dp.coerceIn(8, 32)
        viewModelScope.launch { context.dataStore.edit { it[INPUT_CORNER_KEY] = _inputCornerRadius.value.toString() } }
    }

    fun setInputSquircle(enabled: Boolean) {
        _inputSquircle.value = enabled
        viewModelScope.launch { context.dataStore.edit { it[INPUT_SQUIRCLE_KEY] = enabled.toString() } }
    }

    fun setInputBlurIntensity(intensity: Int) {
        _inputBlurIntensity.value = intensity.coerceIn(0, 100)
        viewModelScope.launch { context.dataStore.edit { it[INPUT_BLUR_INTENSITY_KEY] = _inputBlurIntensity.value.toString() } }
    }

    fun setCustomFontColor(color: String) {
        _customFontColor.value = color
        viewModelScope.launch { context.dataStore.edit { it[CUSTOM_FONT_COLOR_KEY] = color } }
    }

    fun setCustomBgColor(color: String) {
        _customBgColor.value = color
        viewModelScope.launch { context.dataStore.edit { it[CUSTOM_BG_COLOR_KEY] = color } }
    }

    fun setCustomBubbleColor(color: String) {
        _customBubbleColor.value = color
        viewModelScope.launch { context.dataStore.edit { it[CUSTOM_BUBBLE_COLOR_KEY] = color } }
    }

    fun setCustomTextColor(color: String) {
        _customTextColor.value = color
        viewModelScope.launch { context.dataStore.edit { it[CUSTOM_TEXT_COLOR_KEY] = color } }
    }

    fun setCustomFont(fontPath: String) {
        _customFont.value = fontPath
        viewModelScope.launch { context.dataStore.edit { it[CUSTOM_FONT_KEY] = fontPath } }
    }

    // === Preference setters ===
    fun setPrefDefaultModel(model: String) {
        _prefDefaultModel.value = model
        viewModelScope.launch { context.dataStore.edit { it[PREF_DEFAULT_MODEL] = model } }
    }

    fun setPrefStartupMode(mode: String) {
        _prefStartupMode.value = mode
        viewModelScope.launch { context.dataStore.edit { it[PREF_STARTUP_MODE] = mode } }
    }

    fun setPrefStartupSession(sessionId: String) {
        _prefStartupSession.value = sessionId
        viewModelScope.launch { context.dataStore.edit { it[PREF_STARTUP_SESSION] = sessionId } }
    }

    fun setPrefAgentThinkLevel(level: Int) {
        _prefAgentThinkLevel.value = level.coerceIn(0, 4)
        viewModelScope.launch { context.dataStore.edit { it[PREF_AGENT_THINK_LEVEL] = _prefAgentThinkLevel.value.toString() } }
    }

    fun setPrefAutoCompress(enabled: Boolean) {
        _prefAutoCompress.value = enabled
        viewModelScope.launch { context.dataStore.edit { it[PREF_AUTO_COMPRESS] = enabled.toString() } }
    }

    fun setPrefAutoCompressThreshold(threshold: Int) {
        _prefAutoCompressThreshold.value = threshold.coerceIn(100000, 900000)
        viewModelScope.launch { context.dataStore.edit { it[PREF_AUTO_COMPRESS_THRESHOLD] = _prefAutoCompressThreshold.value.toString() } }
    }

    fun setPrefLongTermMemory(enabled: Boolean) {
        _prefLongTermMemory.value = enabled
        viewModelScope.launch { context.dataStore.edit { it[PREF_LONG_TERM_MEMORY] = enabled.toString() } }
        if (enabled) loadMemoryFile() else _memoryContent.value = ""
    }

    fun setPrefMemoryAutoWrite(enabled: Boolean) {
        _prefMemoryAutoWrite.value = enabled
        viewModelScope.launch { context.dataStore.edit { it[PREF_MEMORY_AUTO_WRITE] = enabled.toString() } }
    }

    fun setPrefModelHabit(habit: String) {
        _prefModelHabit.value = habit.take(10)
        viewModelScope.launch { context.dataStore.edit { it[PREF_MODEL_HABIT] = _prefModelHabit.value } }
    }

    fun setPrefScenario(scenario: String) {
        _prefScenario.value = scenario
        viewModelScope.launch { context.dataStore.edit { it[PREF_SCENARIO] = scenario } }
    }

    // === Long-term memory (MEMORY.md) ===
    private fun getMemoryFile(): java.io.File {
        val dir = com.mimo.app.agent.AgentEngine(context, getActiveApiService()).workspaceDir
        return java.io.File(dir, "MEMORY.md")
    }

    fun loadMemoryFile() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = getMemoryFile()
                if (file.exists()) {
                    _memoryContent.value = file.readText()
                }
            } catch (_: Exception) {}
        }
    }

    fun saveMemoryFile(content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = getMemoryFile()
                file.parentFile?.mkdirs()
                file.writeText(content)
                _memoryContent.value = content
            } catch (_: Exception) {}
        }
    }

    /**
     * Analyze a crash log with AI.
     * Returns CrashAnalysis with severity (1-5), responsibility (A/B/C), summary, suggestions.
     */
    suspend fun analyzeCrash(crashLog: String): com.mimo.app.ui.screens.CrashAnalysis? {
        return try {
            // Use first available model from API
            val model = try {
                val models = getActiveApiService().listModels()
                models.firstOrNull { it.contains("mimo-v") && !it.contains("tts") && !it.contains("asr") }
                    ?: models.firstOrNull()
                    ?: getApiModel()
            } catch (_: Exception) { getApiModel() }

            val prompt = """你是崩溃分析专家。分析以下 Android 应用崩溃日志。

评估两个维度：
1. 严重等级（1-5）：1=轻微自身问题 2=一般自身问题 3=应用+自身问题 4=严重应用问题 5=致命崩溃+设备问题
2. 责任归属：C=自身问题 B=应用+自己问题 A=应用问题（C→A 越来越严重）

崩溃日志：
$crashLog

严格按以下格式回复（每行一个字段，不要多余文字）：
SEVERITY: [1-5的数字]
RESPONSIBILITY: [A/B/C]
SUMMARY: [一句话总结崩溃原因]
SUGGESTIONS: [用户可以做什么，如改设置/重装/无法自行解决需反馈GitHub，多项用分号分隔]"""

            val request = getActiveApiService().buildRequest(
                messages = listOf(Message(role = "user", content = prompt)),
                model = model,
                thinkingConfig = ThinkingConfig(type = "disabled"),
                enableSearch = false
            )
            var result = ""
            getActiveApiService().chatCompletion(request).collect { chunk ->
                if (chunk is StreamChunk.Data) result += chunk.content
            }

            // Parse response
            val severity = Regex("SEVERITY:\\s*(\\d)").find(result)?.groupValues?.get(1)?.toIntOrNull() ?: 3
            val responsibility = Regex("RESPONSIBILITY:\\s*([ABC])").find(result)?.groupValues?.get(1) ?: "B"
            val summary = Regex("SUMMARY:\\s*(.+)").find(result)?.groupValues?.get(1)?.trim() ?: "未知原因"
            val suggestions = Regex("SUGGESTIONS:\\s*(.+)").find(result)?.groupValues?.get(1)?.trim() ?: ""

            com.mimo.app.ui.screens.CrashAnalysis(
                severity = severity.coerceIn(1, 5),
                responsibility = responsibility,
                summary = summary,
                suggestions = suggestions,
                raw = result
            )
        } catch (_: Exception) {
            null
        }
    }

    /** Backup all conversations to Download directory. */
    fun backupAllChats() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val allData = gson.toJson(_sessions.value)
                val fileName = "mimo_chats_backup_${System.currentTimeMillis()}.json"
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    val values = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/json")
                        put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download")
                    }
                    val uri = context.contentResolver.insert(
                        android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    uri?.let { context.contentResolver.openOutputStream(it)?.use { it.write(allData.toByteArray()) } }
                } else {
                    val dir = android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_DOWNLOADS)
                    java.io.File(dir, fileName).writeText(allData)
                }
            } catch (_: Exception) {}
        }
    }

    /** Auto-write memory after assistant response (if enabled). */
    private fun maybeAutoWriteMemory(userText: String, assistantReply: String) {
        if (!_prefMemoryAutoWrite.value || !_prefLongTermMemory.value) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val existing = _memoryContent.value
                val prompt = """你是记忆整理助手。根据以下对话，提取值得长期记住的信息（用户偏好、重要事实、技术决策等）。
已有记忆：
$existing

新对话：
用户：$userText
AI：$assistantReply

如果无需更新，回复"无需更新"。否则输出完整的更新后记忆内容（Markdown格式）。"""

                val request = getActiveApiService().buildRequest(
                    messages = listOf(Message(role = "user", content = prompt)),
                    model = getApiModel(),
                    thinkingConfig = ThinkingConfig(type = "disabled"),
                    enableSearch = false
                )
                var result = ""
                getActiveApiService().chatCompletion(request).collect { chunk ->
                    if (chunk is StreamChunk.Data) result += chunk.content
                }
                if (result.isNotBlank() && result.trim() != "无需更新") {
                    saveMemoryFile(result.trim())
                }
            } catch (_: Exception) {}
        }
    }

    fun setAgentApiKey(key: String) {
        _agentApiKey.value = key
        val effectiveKey = if (key.isNotBlank()) key else _apiKey.value
        val effectiveUrl = if (key.isNotBlank()) _agentBaseUrl.value else "https://api.xiaomimimo.com/v1"
        agentChatService.updateApiKey(effectiveKey)
        agentChatService.updateBaseUrl(effectiveUrl)
        agentEngine?.let {
            val agentToolService = MiMoApiService()
            agentToolService.updateApiKey(effectiveKey)
            agentToolService.updateBaseUrl(effectiveUrl)
            agentEngine = createAgentEngine(agentToolService)
        }
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[AGENT_API_KEY] = key
            }
        }
    }

    fun setAgentBaseUrl(url: String) {
        _agentBaseUrl.value = url
        val effectiveKey = if (_agentApiKey.value.isNotBlank()) _agentApiKey.value else _apiKey.value
        agentChatService.updateApiKey(effectiveKey)
        agentChatService.updateBaseUrl(url)
        agentEngine?.let {
            val agentToolService = MiMoApiService()
            agentToolService.updateApiKey(effectiveKey)
            agentToolService.updateBaseUrl(url)
            agentEngine = createAgentEngine(agentToolService)
        }
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[AGENT_BASE_URL] = url
            }
        }
    }

    fun setWorkspacePath(path: String) {
        _workspacePath.value = path.trim()
        agentEngine?.let {
            val agentToolService = MiMoApiService()
            val key = if (_agentApiKey.value.isNotBlank()) _agentApiKey.value else _apiKey.value
            val url = if (_agentApiKey.value.isNotBlank()) _agentBaseUrl.value else "https://api.xiaomimimo.com/v1"
            agentToolService.updateApiKey(key)
            agentToolService.updateBaseUrl(url)
            agentEngine = createAgentEngine(agentToolService)
        }
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[WORKSPACE_PATH_KEY] = path.trim()
            }
        }
    }

    fun setZhipuApiKey(key: String) {
        _zhipuApiKey.value = key
        agentEngine?.zhipuApiKey = key
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[ZHIPU_API_KEY] = key
            }
        }
    }

    fun setModel(model: String) {
        if (_currentModel.value != model) {
            _currentModel.value = model
            if (_forceNewSessionOnModelSwitch.value) {
                // New chat with the new model — leave the old session's model untouched
                createNewSession()
            } else {
                // Stay in this session: persist the choice onto it
                _currentSession.value?.let { cur ->
                    if (cur.model != model) {
                        val updated = cur.copy(model = model)
                        _currentSession.value = updated
                        _sessions.value = _sessions.value.map { if (it.id == updated.id) updated else it }
                        saveSessions()
                    }
                }
            }
        }
    }

    fun toggleThinking() {
        _enableThinking.value = !_enableThinking.value
    }

    fun setThinkingLevel(level: Int) {
        _thinkingLevel.value = level.coerceIn(0, 4)
        _enableThinking.value = level > 0
        viewModelScope.launch {
            context.dataStore.edit { it[THINKING_LEVEL_KEY] = _thinkingLevel.value.toString() }
        }
    }

    private fun buildThinkingConfig(): ThinkingConfig {
        return when (_thinkingLevel.value) {
            0 -> ThinkingConfig(type = "disabled")
            1 -> ThinkingConfig(type = "enabled", budget = 1024)
            2 -> ThinkingConfig(type = "enabled", budget = 4096)
            3 -> ThinkingConfig(type = "enabled", budget = 8192)
            4 -> ThinkingConfig(type = "enabled", budget = 16384)
            else -> ThinkingConfig(type = "enabled", budget = 4096)
        }
    }

    fun toggleSearch() {
        _enableSearch.value = !_enableSearch.value
    }

    fun toggleSettings() {
        _showSettings.value = !_showSettings.value
    }

    fun createNewSession() {
        val session = ChatSession(model = _currentModel.value)
        _currentSession.value = session
    }

    fun selectSession(sessionId: String) {
        val target = _sessions.value.find { it.id == sessionId } ?: return
        _currentSession.value = target
        // Restore this session's own model (each session keeps its selection)
        val sessionModel = target.model
        if (sessionModel.isNotBlank() && _currentModel.value != sessionModel) {
            _currentModel.value = sessionModel
        }
    }

    fun renameSession(sessionId: String, newTitle: String) {
        val updated = _sessions.value.find { it.id == sessionId }?.copy(title = newTitle) ?: return
        _sessions.value = _sessions.value.map { if (it.id == sessionId) updated else it }
        if (_currentSession.value?.id == sessionId) {
            _currentSession.value = updated
        }
        saveSessions()
    }

    fun deleteSession(sessionId: String) {
        _sessions.value = _sessions.value.filter { it.id != sessionId }
        if (_currentSession.value?.id == sessionId) {
            _currentSession.value = _sessions.value.lastOrNull()
        }
        saveSessions()
    }

    fun editAndResend(messageId: String, newText: String) {
        val session = _currentSession.value ?: return
        if (newText.isBlank()) return

        val msgIndex = session.messages.indexOfFirst { it.id == messageId }
        if (msgIndex < 0 || session.messages[msgIndex].role != "user") return

        // Remove the user message and the assistant response after it
        val messagesBefore = session.messages.take(msgIndex)
        val messagesAfter = session.messages.drop(msgIndex + 1).dropWhile { it.role == "assistant" }

        // Edit text only — preserve imageUri / fileName so re-sent message keeps attachments
        val editedUserMsg = session.messages[msgIndex].copy(content = newText)
        val assistantMsg = ChatMessage(role = "assistant", content = "", isStreaming = true)

        val updatedMessages = messagesBefore + editedUserMsg + assistantMsg + messagesAfter
        updateSession(session.copy(messages = updatedMessages))

        // Now trigger the API call
        streamingJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                _isGenerating.value = true
                _error.value = null

                val apiMessages = mutableListOf<Message>(
                    Message(role = "system", content = getSystemPrompt())
                )

                // Add conversation history up to the edited message; re-attach image on the edited msg
                val history = updatedMessages.filter { it.role == "user" || (it.role == "assistant" && it.content.isNotBlank()) }
                for (msg in history) {
                    if (msg.role == "user") {
                        val imgB64 = msg.imageUri?.let { uri ->
                            try {
                                context.contentResolver.openInputStream(android.net.Uri.parse(uri))?.use { s ->
                                    android.util.Base64.encodeToString(s.readBytes(), android.util.Base64.NO_WRAP)
                                }
                            } catch (_: Exception) { null }
                        }
                        apiMessages.add(getActiveApiService().buildUserMessage(
                            text = msg.content,
                            imageBase64 = imgB64
                        ))
                    } else if (msg.role == "assistant" && msg.content.isNotBlank()) {
                        apiMessages.add(Message(role = "assistant", content = msg.content))
                    }
                }

                val activeApi = getActiveApiService()
                val request = activeApi.buildRequest(
                    messages = apiMessages,
                    model = getApiModel(),
                    thinkingConfig = buildThinkingConfig(),
                    enableSearch = _enableSearch.value
                )

                var fullContent = ""
                var fullReasoning = ""
                var allAnnotations = mutableListOf<com.mimo.app.data.model.Annotation>()
                var lastDataTime = System.currentTimeMillis()

                val watchdogJob = launch {
                    while (true) {
                        kotlinx.coroutines.delay(10_000)
                        if (System.currentTimeMillis() - lastDataTime > 300_000) {
                            _isGenerating.value = false
                            val current = _currentSession.value
                            if (current != null) {
                                updateSession(current.copy(messages = current.messages.map {
                                    if (it.isStreaming) it.copy(isStreaming = false) else it
                                }))
                            }
                            break
                        }
                    }
                }

                activeApi.chatCompletion(request).collect { chunk ->
                    lastDataTime = System.currentTimeMillis()
                    when (chunk) {
                        is StreamChunk.Data -> {
                            fullContent += chunk.content
                            fullReasoning += chunk.reasoning
                            chunk.annotations?.let { allAnnotations.addAll(it) }
                            val current = _currentSession.value ?: return@collect
                            val updatedMsgs = current.messages.toMutableList()
                            val lastIdx = updatedMsgs.indexOfLast { it.isStreaming }
                            if (lastIdx >= 0) {
                                updatedMsgs[lastIdx] = updatedMsgs[lastIdx].copy(content = fullContent, reasoningContent = fullReasoning)
                                updateSession(current.copy(messages = updatedMsgs))
                            }
                        }
                        is StreamChunk.Done -> {
                            _isGenerating.value = false
                            watchdogJob.cancel()
                            val current = _currentSession.value ?: return@collect
                            val updatedMsgs = current.messages.toMutableList()
                            val lastIdx = updatedMsgs.indexOfLast { it.isStreaming }
                            if (lastIdx >= 0) {
                                updatedMsgs[lastIdx] = updatedMsgs[lastIdx].copy(
                                    isStreaming = false,
                                    annotations = if (allAnnotations.isNotEmpty()) allAnnotations.toList() else null
                                )
                                updateSession(current.copy(messages = updatedMsgs))
                            }
                        }
                    }
                }
                watchdogJob.cancel()
            } catch (e: kotlinx.coroutines.CancellationException) {
                // user pressed stop — not an error
            } catch (e: Exception) {
                _error.value = e.message ?: "Unknown error"
                val current = _currentSession.value ?: return@launch
                updateSession(current.copy(messages = current.messages
                    .filterNot { it.role == "assistant" && it.content.isBlank() && it.isStreaming }
                    .map { if (it.isStreaming) it.copy(isStreaming = false) else it }
                ))
            } finally {
                _isGenerating.value = false
            }
        }
    }

    /** Regenerate: drop the last assistant reply, re-send the preceding user message. */
    fun regenerate() {
        val session = _currentSession.value ?: return
        if (_isGenerating.value) return
        val msgs = session.messages
        // Find last assistant message that is not streaming
        val assistantIdx = msgs.indexOfLast { it.role == "assistant" && !it.isStreaming && it.content.isNotBlank() }
        if (assistantIdx < 0) return
        // Find the user message before it
        val userIdx = (assistantIdx - 1 downTo 0).firstOrNull { msgs[it].role == "user" } ?: return
        val userMsg = msgs[userIdx]
        // Keep everything before the user message, then re-send
        val before = msgs.take(userIdx)
        val after = msgs.drop(assistantIdx + 1)
        val streamingMsg = ChatMessage(role = "assistant", content = "", isStreaming = true)
        updateSession(session.copy(messages = before + userMsg + streamingMsg + after))

        streamingJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                _isGenerating.value = true
                _error.value = null
                val apiMessages = mutableListOf<Message>(
                    Message(role = "system", content = getSystemPrompt())
                )
                val history = (before + userMsg).filter {
                    it.role == "user" || (it.role == "assistant" && it.content.isNotBlank())
                }
                for (msg in history) {
                    if (msg.role == "user") {
                        val imgB64 = msg.imageUri?.let { uri ->
                            try {
                                context.contentResolver.openInputStream(android.net.Uri.parse(uri))?.use { s ->
                                    android.util.Base64.encodeToString(s.readBytes(), android.util.Base64.NO_WRAP)
                                }
                            } catch (_: Exception) { null }
                        }
                        apiMessages.add(getActiveApiService().buildUserMessage(
                            text = msg.content,
                            imageBase64 = imgB64
                        ))
                    } else if (msg.role == "assistant" && msg.content.isNotBlank()) {
                        apiMessages.add(Message(role = "assistant", content = msg.content))
                    }
                }
                val activeApi = getActiveApiService()
                val request = activeApi.buildRequest(
                    messages = apiMessages,
                    model = getApiModel(),
                    thinkingConfig = buildThinkingConfig(),
                    enableSearch = _enableSearch.value
                )
                streamResponse(activeApi, request, isFirstMessage = false, sessionId = session.id, userText = userMsg.content)
            } catch (e: kotlinx.coroutines.CancellationException) {
                // user pressed stop
            } catch (e: Exception) {
                _error.value = e.message ?: "Unknown error"
                val cur = _currentSession.value
                if (cur != null) {
                    updateSession(cur.copy(messages = cur.messages
                        .filterNot { it.role == "assistant" && it.content.isBlank() && it.isStreaming }
                        .map { if (it.isStreaming) it.copy(isStreaming = false) else it }
                    ))
                }
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun sendMessage(text: String, imageUris: List<Uri> = emptyList(), fileUri: Uri? = null, fileName: String? = null) {
        val session = _currentSession.value ?: return
        if (text.isBlank() && imageUris.isEmpty() && fileUri == null) return

        // "/压缩" command — must be exact match (only the command, nothing before/after)
        if (text.trim() == "/压缩") {
            compressConversation()
            return
        }

        // Context limit check
        if (isContextLimitReached) {
            _error.value = "上下文已达 ${MAX_CONTEXT_TOKENS / 1000}K Token 上限。请开启新对话，或长按进度圆圈压缩会话。"
            return
        }

        val isFirstMessage = session.messages.isEmpty()
        if (isFirstMessage && !_sessions.value.contains(session)) {
            _sessions.value = _sessions.value + session
            saveSessions()
        }
        streamingJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                var fileContent = ""
                var audioBase64: String? = null
                var audioMimeType: String? = null
                var videoBase64: String? = null
                var videoMimeType: String? = null

                if (fileUri != null) {
                    val mimeType = context.contentResolver.getType(fileUri) ?: ""
                    when {
                        mimeType.startsWith("audio/") -> {
                            // raw bytes — BitmapFactory can't decode audio
                            audioBase64 = uriToRawBase64(fileUri)
                            audioMimeType = mimeType
                        }
                        mimeType.startsWith("video/") -> {
                            videoBase64 = uriToRawBase64(fileUri)
                            videoMimeType = mimeType
                        }
                        else -> {
                            fileContent = readFileContent(fileUri) ?: ""
                        }
                    }
                }

                var imageBase64List = imageUris.mapNotNull { uriToBase64(it) }
                var extractedNote = ""

                // Non-vision models can't consume image_url parts — extract to text first
                if (imageBase64List.isNotEmpty() && !supportsVision(_currentModel.value)) {
                    _isGenerating.value = true
                    islandService.showAgentTaskNotification(
                        taskTitle = "MiMo",
                        taskStatus = "正在提取图片内容...",
                        progress = -1
                    )
                    val extracted = extractImageContent(imageBase64List)
                    if (extracted != null) {
                        extractedNote = "\n\n[图片内容 - 已自动提取为文档]\n$extracted"
                        imageBase64List = emptyList() // text-only from here on
                    }
                    // extraction failed → keep images and send as-is (API may still accept or surface a clear error)
                }

                val fullUserContent = buildString {
                    if (text.isNotBlank()) append(text)
                    if (fileContent.isNotBlank()) {
                        if (isNotBlank()) append("\n\n")
                        append("File: ${fileName ?: "file"}\n```\n$fileContent\n```")
                    }
                    if (extractedNote.isNotBlank()) append(extractedNote)
                }

                // Persist picker URIs into app storage — content:// dies after process kill
                val persistedImages = imageUris.mapNotNull { persistImage(it) }
                val userMessage = ChatMessage(
                    role = "user",
                    content = fullUserContent,
                    imageUri = persistedImages.joinToString("|").ifBlank { null },
                    fileName = fileName
                )
                val assistantMessage = ChatMessage(role = "assistant", content = "", isStreaming = true)

                updateSession(session.copy(
                    messages = session.messages + userMessage + assistantMessage
                ))

                _isGenerating.value = true
                _error.value = null

                val isAgent = _currentModel.value.contains("agent") && agentEngine != null

                if (isAgent) {
                    executeAgentFlow(text, fullUserContent, imageBase64List, audioBase64, audioMimeType, videoBase64, videoMimeType, isFirstMessage, session)
                } else {
                    executeNormalFlow(text, fullUserContent, imageBase64List, audioBase64, audioMimeType, videoBase64, videoMimeType, isFirstMessage, session)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                // user pressed stop — not an error
            } catch (e: Exception) {
                _error.value = e.message ?: "Unknown error"
                val current = _currentSession.value ?: return@launch
                updateSession(current.copy(messages = current.messages
                    .filterNot { it.role == "assistant" && it.content.isBlank() && it.isStreaming }
                    .map { if (it.isStreaming) it.copy(isStreaming = false) else it }
                ))
            } finally {
                _isGenerating.value = false
                islandService.cancelNotification()
            }
        }
    }

    private suspend fun executeNormalFlow(
        text: String, fullUserContent: String, imageBase64List: List<String>,
        audioBase64: String?, audioMimeType: String?,
        videoBase64: String?, videoMimeType: String?,
        isFirstMessage: Boolean, session: ChatSession
    ) {
        val apiMessages = mutableListOf<Message>(
            Message(role = "system", content = getSystemPrompt())
        )

        val history = session.messages
        val thinkingOn = buildThinkingConfig().type == "enabled"
        for (msg in history) {
            if (msg.role == "user") {
                // Re-attach persisted images so the model can still "see" them in follow-up messages
                val histImageBase64 = msg.imageUri?.split("|")?.filter { it.isNotBlank() }?.firstOrNull()?.let { path ->
                    try {
                        val file = java.io.File(path)
                        if (file.exists()) {
                            android.util.Base64.encodeToString(file.readBytes(), android.util.Base64.NO_WRAP)
                        } else null
                    } catch (_: Exception) { null }
                }
                apiMessages.add(getActiveApiService().buildUserMessage(
                    text = msg.content,
                    imageBase64 = histImageBase64
                ))
            } else if (msg.role == "assistant" && msg.content.isNotBlank()) {
                apiMessages.add(Message(
                    role = "assistant",
                    content = msg.content,
                    reasoningContent = if (thinkingOn) msg.reasoningContent.takeIf { it.isNotBlank() } else null
                ))
            }
        }

        // fullUserContent = text + file content + extracted image doc — what the model actually needs
        apiMessages.add(getActiveApiService().buildUserMessage(
            text = fullUserContent,
            imageBase64 = imageBase64List.firstOrNull(),
            audioBase64 = audioBase64,
            audioMimeType = audioMimeType,
            videoBase64 = videoBase64,
            videoMimeType = videoMimeType
        ))

        val activeApi = getActiveApiService()
        val request = activeApi.buildRequest(
            messages = apiMessages,
            model = getApiModel(),
            thinkingConfig = buildThinkingConfig(),
            enableSearch = _enableSearch.value
        )

        try {
            islandService.showAgentTaskNotification(
                taskTitle = "MiMo",
                taskStatus = "Thinking...",
                progress = -1
            )
            streamResponse(activeApi, request, isFirstMessage, session.id, text)
        } catch (e: Exception) {
            if (isBalanceError(e) && _agentApiKey.value.isNotBlank()) {
                val fallbackApi = agentChatService
                streamResponse(fallbackApi, request, isFirstMessage, session.id, text)
            } else {
                throw e
            }
        }
    }

    private suspend fun executeAgentFlow(
        text: String, fullUserContent: String, imageBase64List: List<String>,
        audioBase64: String?, audioMimeType: String?,
        videoBase64: String?, videoMimeType: String?,
        isFirstMessage: Boolean, session: ChatSession
    ) {
        val engine = agentEngine ?: return
        val activeApi = getActiveApiService()
        val maxRounds = 5
        agentTaskManager.startSession()

        // Caller appended [user, streaming placeholder]; everything from here on is this run's output.
        val runStartIdx = (_currentSession.value?.messages?.size ?: 1) - 1
        val toolSteps = mutableListOf<Map<String, String>>()

        val apiMessages = mutableListOf<Message>(
            Message(role = "system", content = getSystemPrompt())
        )

        val history = session.messages.filter { !it.isStreaming }
        for (msg in history) {
            when (msg.role) {
                "user" -> apiMessages.add(Message(role = "user", content = msg.content))
                "assistant" -> if (msg.content.isNotBlank()) apiMessages.add(Message(role = "assistant", content = msg.content))
                "tool" -> apiMessages.add(Message(role = "tool", content = msg.content, toolCallId = msg.id))
                "tool_group" -> {
                    // Expand collapsed operations back into tool messages for model context
                    try {
                        val arr = com.google.gson.JsonParser.parseString(msg.content).asJsonArray
                        arr.forEach { el ->
                            val o = el.asJsonObject
                            val t = o.get("tool")?.asString ?: "tool"
                            val r = o.get("result")?.asString ?: ""
                            apiMessages.add(Message(role = "tool", content = r, toolCallId = t))
                        }
                    } catch (_: Exception) {}
                }
            }
        }

        apiMessages.add(activeApi.buildUserMessage(
            text = fullUserContent,
            imageBase64 = imageBase64List.firstOrNull(),
            audioBase64 = audioBase64,
            audioMimeType = audioMimeType,
            videoBase64 = videoBase64,
            videoMimeType = videoMimeType
        ))

        var round = 0
        while (round < maxRounds) {
            round++
            val request = ChatRequest(
                model = getApiModel(),
                messages = apiMessages,
                maxCompletionTokens = 32768,
                temperature = 0.7f,
                stream = false,
                thinking = buildThinkingConfig(),
                responseFormat = com.mimo.app.agent.ToolCallSchema.toResponseFormat()
            )

            val response = try {
                activeApi.chatCompletionStructured(request)
            } catch (e: Exception) {
                if (isBalanceError(e) && _agentApiKey.value.isNotBlank()) {
                    try {
                        agentChatService.chatCompletionStructured(request)
                    } catch (e2: Exception) {
                        _error.value = "Agent request failed: ${e2.message}"
                        val current = _currentSession.value
                        if (current != null) {
                            updateSession(current.copy(messages = current.messages.filterNot {
                                it.role == "assistant" && it.content.isBlank() && it.isStreaming
                            }))
                        }
                        islandService.cancelNotification()
                        return
                    }
                } else {
                    _error.value = "Agent request failed: ${e.message}"
                    val current = _currentSession.value
                    if (current != null) {
                        updateSession(current.copy(messages = current.messages.filterNot {
                            it.role == "assistant" && it.content.isBlank() && it.isStreaming
                        }))
                    }
                    islandService.cancelNotification()
                    return
                }
            }

            val content = response.choices.firstOrNull()?.message?.content?.toString() ?: break
            val rawText = content as? String ?: content.toString()
            val jsonText = extractJson(rawText)
            val structured = try {
                gson.fromJson(jsonText, com.mimo.app.agent.StructuredToolCallResponse::class.java)
            } catch (e: Exception) {
                null
            }
            if (structured == null) {
                // Unparseable output (gson returns null for "null"/empty instead of throwing):
                // show raw text as the reply rather than crashing
                val current = _currentSession.value
                if (current != null) {
                    val updatedMsgs = current.messages.toMutableList()
                    val lastIdx = updatedMsgs.indexOfLast { it.isStreaming }
                    if (lastIdx >= 0) {
                        updatedMsgs[lastIdx] = updatedMsgs[lastIdx].copy(content = rawText, isStreaming = false)
                        updateSession(current.copy(messages = updatedMsgs))
                    }
                }
                islandService.cancelNotification()
                return
            }

            val toolCalls = structured.toolCalls
            if (toolCalls.isNullOrEmpty()) {
                val responseText = structured.response?.trim().orEmpty()
                if (responseText.isEmpty() && round < maxRounds) {
                    // BUG fix: model thought but returned no answer — nudge it once more
                    // instead of ending the task with a blank reply
                    apiMessages.add(Message(role = "assistant", content = content))
                    apiMessages.add(Message(
                        role = "user",
                        content = "Continue. Provide your final response to the user now. Do not stop at thinking only."
                    ))
                    continue
                }
                val finalText = responseText.ifBlank {
                    structured.thinking?.trim()?.takeIf { it.isNotBlank() }
                        // Surface the raw model JSON rather than a dead-end placeholder,
                        // so an empty-field response stays diagnosable on-device.
                        ?: rawText.trim().takeIf { it.isNotBlank() }
                        ?: "No response"
                }
                val current = _currentSession.value
                if (current != null) {
                    // Collapse this run's live tool cards into one group, reply goes below it
                    val collapsed = collapseRunMessages(current, toolSteps, runStartIdx)
                    updateSession(current.copy(
                        messages = collapsed + ChatMessage(role = "assistant", content = finalText, isStreaming = false)
                    ))
                }
                if (isFirstMessage && finalText.isNotBlank()) {
                    generateTitle(session.id, text, finalText)
                }
                islandService.cancelNotification()
                return
            }

            apiMessages.add(Message(role = "assistant", content = content))

            // Surface this round's thinking/narration to the user LIVE (previously discarded).
            // content = short narration the model said alongside tool calls;
            // reasoningContent = its thinking (renders as collapsible "Thinking" card).
            val narration = structured.response?.trim().orEmpty()
            val roundThink = structured.thinking?.trim().orEmpty()
            if (narration.isNotBlank() || roundThink.isNotBlank()) {
                if (narration.isNotBlank()) {
                    // also surface the narration in the ongoing notification
                    islandService.showAgentTaskNotification(
                        taskTitle = "MiMo Agent",
                        taskStatus = narration.take(80),
                        progress = -1
                    )
                }
                val cur = _currentSession.value
                if (cur != null) {
                    updateSession(cur.copy(messages = cur.messages + ChatMessage(
                        role = "assistant",
                        content = narration,
                        reasoningContent = roundThink,
                        isStreaming = false
                    )))
                }
            }

            toolCalls.forEachIndexed { idx, tc ->
                _toolExecuting.value = true
                islandService.showAgentTaskNotification(
                    taskTitle = "MiMo Agent",
                    taskStatus = "Executing: ${tc.tool}",
                    progress = ((idx) * 100 / toolCalls.size)
                )
                var toolResult = try {
                    engine.executeTool(tc.tool, tc.args, _agentPermissionMode.value)
                } catch (e: Exception) {
                    "Error: ${e.message}"
                } finally {
                    _toolExecuting.value = false
                    _pendingToolCall.value = null
                }
                // Tool reported a missing system permission → suspend, jump to Settings,
                // wait for the user to grant, then retry the SAME tool call once.
                if (toolResult.startsWith("NEED_PERMISSION:")) {
                    val rest = toolResult.removePrefix("NEED_PERMISSION:")
                    val type = rest.substringBefore("|", "storage")
                    val reason = rest.substringAfter("|", "This permission is required")
                    val grant = CompletableDeferred<Boolean>()
                    permissionGrant = grant
                    _pendingPermission.value = PermissionRequest(type, reason)
                    // Notify user: agent needs a permission
                    islandService.showAgentTaskComplete(
                        taskTitle = "MiMo Agent 需要权限",
                        result = "需要「${permissionLabel(type)}」权限：$reason\n点按返回 App 授权"
                    )
                    openPermissionSettings(type)
                    val granted = grant.await()  // suspend the flow until user resolves
                    permissionGrant = null
                    _pendingPermission.value = null
                    if (granted) {
                        islandService.showAgentTaskNotification(
                            taskTitle = "MiMo Agent",
                            taskStatus = "Retrying ${tc.tool} after grant...",
                            progress = ((idx) * 100 / toolCalls.size)
                        )
                        toolResult = try {
                            engine.executeTool(tc.tool, tc.args, _agentPermissionMode.value)
                        } catch (e: Exception) {
                            "Error: ${e.message}"
                        }
                        // If it STILL needs permission (grant didn't take effect), give up on this tool
                        if (toolResult.startsWith("NEED_PERMISSION:")) {
                            toolResult = "权限「${permissionLabel(type)}」仍未生效（已授权但工具仍报缺失）。请检查是否在系统设置中真正开启了该权限，再让 Agent 重试。"
                        }
                    } else {
                        toolResult = "用户放弃授权（${permissionLabel(type)}），跳过此操作。"
                    }
                }
                val displayResult = toolResult
                toolSteps.add(mapOf("tool" to tc.tool, "result" to displayResult))

                val current = _currentSession.value
                if (current != null) {
                    val toolMsg = ChatMessage(
                        role = "tool",
                        content = "[${tc.tool}] $displayResult",
                        id = tc.tool
                    )
                    updateSession(current.copy(messages = current.messages + toolMsg))
                }

                apiMessages.add(Message(role = "tool", content = displayResult, toolCallId = tc.tool))
            }
            // Continue loop for next round of tool calls
        }

        // All tool rounds done, stream final response
        val finalRequest = activeApi.buildRequest(
            messages = apiMessages,
            model = getApiModel(),
            thinkingConfig = buildThinkingConfig(),
            enableSearch = false
        )

        val current = _currentSession.value
        if (current != null) {
            val collapsed = collapseRunMessages(current, toolSteps, runStartIdx)
            val streamingMsg = ChatMessage(role = "assistant", content = "", isStreaming = true)
            updateSession(current.copy(messages = collapsed + streamingMsg))
        }

        streamResponse(activeApi, finalRequest, isFirstMessage, session.id, text)
        agentTaskManager.endSession()
        islandService.cancelNotification()
        // Notify user: agent output finished
        islandService.showAgentTaskComplete(
            taskTitle = "MiMo Agent 完成",
            result = "输出已完成，点击查看结果"
        )
    }

    /**
     * Replace this run's live tool messages (and the streaming placeholder) with a
     * single collapsed "tool_group" message, keeping history before the run intact.
     * Live narration messages (model's per-round thinking/speech) are PRESERVED above
     * the operations group. During execution each tool shows individually; collapse
     * happens once at the end.
     */
    private fun collapseRunMessages(
        current: ChatSession,
        toolSteps: List<Map<String, String>>,
        runStartIdx: Int
    ): List<com.mimo.app.data.model.ChatMessage> {
        val msgs = current.messages
        val beforeRun = if (runStartIdx in 0..msgs.size) msgs.subList(0, runStartIdx) else msgs
        // run segment = placeholder + narrations + individual tool cards
        val runSeg = if (runStartIdx < msgs.size) msgs.subList(runStartIdx, msgs.size) else emptyList()

        // Collect all narration + thinking into the Operations group
        val narrations = runSeg.filter {
            it.role == "assistant" && !it.isStreaming &&
                    (it.content.isNotBlank() || it.reasoningContent.isNotBlank())
        }

        // Merge narration/thinking as extra context into the tool_group steps
        val mergedSteps = toolSteps.toMutableList()
        for (n in narrations) {
            if (n.reasoningContent.isNotBlank()) {
                mergedSteps.add(mapOf("tool" to "思考", "result" to n.reasoningContent))
            }
            if (n.content.isNotBlank()) {
                mergedSteps.add(mapOf("tool" to "旁白", "result" to n.content))
            }
        }

        if (mergedSteps.isEmpty()) return beforeRun
        val groupMsg = com.mimo.app.data.model.ChatMessage(
            role = "tool_group",
            content = gson.toJson(mergedSteps)
        )
        return beforeRun + groupMsg
    }

    private suspend fun streamResponse(
        activeApi: MiMoApiService, request: ChatRequest,
        isFirstMessage: Boolean, sessionId: String, userText: String
    ) {
        var fullContent = ""
        var fullReasoning = ""
        var allAnnotations = mutableListOf<com.mimo.app.data.model.Annotation>()
        var lastDataTime = System.currentTimeMillis()
        var thinkingNotified = false
        var reasoningStartMs = 0L
        var reasoningEndMs = 0L

        // Speed sampling (Ultra models only)
        val trackSpeed = _currentModel.value.contains("ultraspeed")
        val streamStart = System.currentTimeMillis()
        var lastSampleTime = 0L
        var lastSampleContent = 0
        var lastSampleReasoning = 0
        var peakTotal = 0f
        var firstTokenAt = -1L
        var thinkEnded = false
        _speedStats.value = if (trackSpeed) SpeedStats() else null

        fun sampleSpeed(force: Boolean = false) {
            if (!trackSpeed) return
            val now = System.currentTimeMillis()
            val sinceLast = now - lastSampleTime
            if (!force && sinceLast < 300) return
            val dt: Float = if (lastSampleTime == 0L) 0.3f else sinceLast / 1000f
            if (lastSampleTime != 0L && dt > 0f) {
                val thinkSpeed = (fullReasoning.length - lastSampleReasoning) / dt
                val answerSpeed = (fullContent.length - lastSampleContent) / dt
                val total = thinkSpeed + answerSpeed
                if (total > peakTotal) peakTotal = total
                val prev = _speedStats.value ?: SpeedStats()
                val t = (now - streamStart) / 1000f
                // Join point: first moment content starts flowing after thinking
                val thinkEnd = if (!thinkEnded && fullContent.isNotEmpty() && fullReasoning.isNotEmpty()) {
                    thinkEnded = true
                    t
                } else prev.thinkEndT
                val point = SpeedPoint(t, thinkSpeed, answerSpeed)
                _speedStats.value = prev.copy(
                    points = (prev.points + point).takeLast(240),
                    currentTotal = total,
                    currentThink = thinkSpeed,
                    currentAnswer = answerSpeed,
                    peakTotal = peakTotal,
                    elapsedSec = t,
                    firstTokenMs = firstTokenAt,
                    thinkEndT = thinkEnd
                )
            }
            lastSampleTime = now
            lastSampleContent = fullContent.length
            lastSampleReasoning = fullReasoning.length
        }

        val watchdogJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                kotlinx.coroutines.delay(10_000)
                if (System.currentTimeMillis() - lastDataTime > 90_000) {
                    _isGenerating.value = false
                    if (trackSpeed) {
                        val prev = _speedStats.value
                        if (prev != null) _speedStats.value = prev.copy(finished = true, currentTotal = 0f, currentThink = 0f, currentAnswer = 0f)
                    }
                    val current = _currentSession.value
                    if (current != null) {
                        updateSession(current.copy(messages = current.messages.map {
                            if (it.isStreaming) it.copy(isStreaming = false) else it
                        }))
                    }
                    break
                }
            }
        }

        try {
            activeApi.chatCompletion(request).collect { chunk ->
                lastDataTime = System.currentTimeMillis()
                when (chunk) {
                    is StreamChunk.Data -> {
                        fullContent += chunk.content
                        fullReasoning += chunk.reasoning
                        if (chunk.reasoning.isNotBlank() && reasoningStartMs == 0L) {
                            reasoningStartMs = System.currentTimeMillis()
                        }
                        if (chunk.content.isNotBlank() && reasoningStartMs != 0L && reasoningEndMs == 0L) {
                            reasoningEndMs = System.currentTimeMillis()
                        }
                        if (firstTokenAt < 0 && (chunk.content.isNotBlank() || chunk.reasoning.isNotBlank())) {
                            firstTokenAt = System.currentTimeMillis() - streamStart
                        }
                        sampleSpeed()
                        if (chunk.reasoning.isNotBlank() && !thinkingNotified) {
                            thinkingNotified = true
                            islandService.showAgentTaskNotification(
                                taskTitle = "MiMo",
                                taskStatus = "Thinking deeply...",
                                progress = -1
                            )
                        }
                        if (chunk.content.isNotBlank() && thinkingNotified) {
                            thinkingNotified = false
                            islandService.showAgentTaskNotification(
                                taskTitle = "MiMo - Thinking Done",
                                taskStatus = chunk.content.take(80),
                                progress = 100
                            )
                        }
                        chunk.annotations?.let { allAnnotations.addAll(it) }
                        val current = _currentSession.value ?: return@collect
                        val updatedMessages = current.messages.toMutableList()
                        val lastIdx = updatedMessages.indexOfLast { it.isStreaming }
                        if (lastIdx >= 0) {
                            updatedMessages[lastIdx] = updatedMessages[lastIdx].copy(content = fullContent, reasoningContent = fullReasoning)
                            updateSession(current.copy(messages = updatedMessages))
                        }
                    }
                    is StreamChunk.Done -> {
                        _isGenerating.value = false
                        watchdogJob.cancel()
                        if (trackSpeed) {
                            sampleSpeed(force = true)
                            val prev = _speedStats.value
                            if (prev != null) {
                                _speedStats.value = prev.copy(
                                    currentTotal = 0f, currentThink = 0f, currentAnswer = 0f,
                                    finished = true
                                )
                            }
                        }
                        val current = _currentSession.value ?: return@collect
                        val updatedMessages = current.messages.toMutableList()
                        val lastIdx = updatedMessages.indexOfLast { it.isStreaming }
                        if (lastIdx >= 0) {
                            val duration = when {
                                reasoningEndMs > 0 && reasoningStartMs > 0 -> reasoningEndMs - reasoningStartMs
                                reasoningStartMs > 0 -> System.currentTimeMillis() - reasoningStartMs
                                else -> 0L
                            }
                            updatedMessages[lastIdx] = updatedMessages[lastIdx].copy(
                                isStreaming = false,
                                annotations = if (allAnnotations.isNotEmpty()) allAnnotations.toList() else null,
                                reasoningDurationMs = duration
                            )
                            updateSession(current.copy(messages = updatedMessages))
                        }
                        recalcTokens()
                        maybeAutoWriteMemory(userText, fullContent)
                        // Auto read-aloud: only clean prose, skip agent/tool content
                        if (_autoReadAloud.value && fullContent.isNotBlank()) {
                            val isAgentRun = _currentModel.value.contains("agent")
                            val ttsText = filterForTTS(fullContent)
                            if (ttsText.isNotBlank() && ttsText.length > 2) {
                                // In agent mode, skip if content looks like tool output
                                val skipAgent = isAgentRun && (fullContent.startsWith("{") || fullContent.contains("\"tool_calls\""))
                                if (!skipAgent) {
                                    readAloud(ttsText)
                                }
                            }
                        }
                        if (isFirstMessage && fullContent.isNotBlank()) {
                            generateTitle(sessionId, userText, fullContent)
                        }
                    }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            // User pressed stop — stopGeneration already cleaned UI; do not show an error
            throw e
        } catch (e: Exception) {
            // Mid-stream failure: keep whatever partial content arrived, just stop the spinner
            _error.value = e.message ?: "连接中断"
            watchdogJob.cancel()
            if (trackSpeed) {
                val prev = _speedStats.value
                if (prev != null) _speedStats.value = prev.copy(finished = true, currentTotal = 0f, currentThink = 0f, currentAnswer = 0f)
            }
            val current = _currentSession.value
            if (current != null) {
                updateSession(current.copy(messages = current.messages.map {
                    if (it.isStreaming) it.copy(isStreaming = false, content = it.content.ifBlank { fullContent }, reasoningContent = it.reasoningContent.ifBlank { fullReasoning }) else it
                }))
            }
        }
        watchdogJob.cancel()
    }

    private fun generateTitle(sessionId: String, userMsg: String, aiResponse: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val activeApi = getActiveApiService()
                val prompt = "Generate a very short title (max 20 chars, Chinese preferred) for this conversation.\nUser: ${userMsg.take(200)}\nAssistant: ${aiResponse.take(200)}\nOutput ONLY the title, no quotes, no punctuation."
                val titleMessages = listOf(
                    Message(role = "user", content = prompt)
                )
                val request = ChatRequest(
                    model = _modelIds.value.firstOrNull { it.contains("flash") }
                        ?: _modelIds.value.firstOrNull()
                        ?: "mimo-v2.6-flash",
                    messages = titleMessages,
                    maxCompletionTokens = 50,
                    temperature = 0.3f,
                    stream = false,
                    thinking = ThinkingConfig(type = "disabled")
                )
                val json = gson.toJson(request)
                val body = json.toRequestBody("application/json".toMediaType())
                val httpRequest = Request.Builder()
                    .url("${activeApi.getBaseUrl()}/chat/completions")
                    .addHeader("Authorization", "Bearer ${activeApi.getApiKey()}")
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build()
                val response = activeApi.getClient().newCall(httpRequest).execute()
                if (response.isSuccessful) {
                    val respBody = response.body?.string() ?: return@launch
                    val resp = gson.fromJson(respBody, ChatResponse::class.java)
                    val rawTitle = resp.choices.firstOrNull()?.message?.content?.toString() ?: ""
                    val title = rawTitle.trim().replace("\"", "").replace("'", "").take(20)
                    if (title.isNotBlank()) {
                        val current = _sessions.value.find { it.id == sessionId }
                        if (current != null && current.title != title) {
                            val updated = current.copy(title = title)
                            _sessions.value = _sessions.value.map { if (it.id == sessionId) updated else it }
                            if (_currentSession.value?.id == sessionId) {
                                _currentSession.value = updated
                            }
                            saveSessions()
                        }
                    }
                }
            } catch (e: Exception) {
                // Silent fail - title will stay as user message excerpt
            }
        }
    }

    fun stopGeneration() {
        streamingJob?.cancel()
        _isGenerating.value = false
        _error.value = null
        _pendingToolCall.value = null
        islandService.cancelNotification()
        val current = _currentSession.value ?: return
        val updatedMessages = current.messages.map {
            if (it.isStreaming) it.copy(isStreaming = false) else it
        }
        updateSession(current.copy(messages = updatedMessages))
    }

    fun approveToolCall() {
        _toolExecuting.value = true
        agentEngine?.approvePendingConfirmation()
        _pendingToolCall.value = null
    }

    fun denyToolCall() {
        agentEngine?.denyPendingConfirmation()
        _pendingToolCall.value = null
    }

    fun permissionLabel(type: String): String = when (type) {
        "accessibility" -> "无障碍服务"
        "overlay" -> "悬浮窗"
        "storage" -> "所有文件访问"
        "projection" -> "屏幕录制"
        "notification" -> "通知"
        "mic" -> "麦克风"
        else -> type
    }

    /** Jump straight to the relevant system Settings page for this permission type. */
    fun openPermissionSettings(type: String) {
        val pkg = context.packageName
        val intent = try {
            when (type) {
                "accessibility" ->
                    android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                "overlay" ->
                    android.content.Intent(
                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:$pkg")
                    )
                "storage" ->
                    if (android.os.Build.VERSION.SDK_INT >= 30) {
                        android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            android.net.Uri.parse("package:$pkg")
                        )
                    } else {
                        android.content.Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            android.net.Uri.parse("package:$pkg")
                        )
                    }
                "notification" ->
                    android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, pkg)
                // projection / mic / anything else: app detail page (closest jumpable surface)
                else ->
                    android.content.Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:$pkg")
                    )
            }
        } catch (e: Exception) {
            android.content.Intent(
                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.parse("package:$pkg")
            )
        }
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            _error.value = "无法打开系统设置: ${e.message}"
        }
    }

    fun dismissPermissionRequest() {
        // Backdrop dismiss = user walked away; resume the suspended flow as "skipped".
        permissionGrant?.complete(false)
        permissionGrant = null
        _pendingPermission.value = null
    }

    /** User tapped "已授权" after granting in system Settings — resume and retry the tool. */
    fun resolvePermissionGranted() {
        permissionGrant?.complete(true)
        permissionGrant = null
        _pendingPermission.value = null
    }

    /** User tapped "放弃" — resume the suspended flow without retrying. */
    fun resolvePermissionSkipped() {
        permissionGrant?.complete(false)
        permissionGrant = null
        _pendingPermission.value = null
    }

    fun readAloud(text: String) {
        stopSpeaking()
        val filteredText = filterForSpeech(text)
        if (filteredText.isBlank()) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                _isSpeaking.value = true
                // Streaming playback: 24kHz PCM16LE mono, stream chunks into AudioTrack as they arrive
                val sampleRate = 24000
                val minBuf = android.media.AudioTrack.getMinBufferSize(
                    sampleRate,
                    android.media.AudioFormat.CHANNEL_OUT_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT
                )
                val track = android.media.AudioTrack.Builder()
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        android.media.AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, 48000)) // ≥1s @24kHz mono 16bit
                    .setTransferMode(android.media.AudioTrack.MODE_STREAM)
                    .build()
                currentAudioTrack = track
                track.play()

                var totalBytes = 0
                val ok = ttsService.synthesizeStream(filteredText) { chunk ->
                    // blocking write back-pressures naturally against playback buffering
                    totalBytes += track.write(chunk, 0, chunk.size)
                }

                if (ok && totalBytes > 0) {
                    // stream fully received — wait until playback head catches up (PCM16 mono → frames = bytes/2)
                    val writtenFrames = totalBytes / 2
                    val deadline = System.currentTimeMillis() +
                        (writtenFrames * 1000L / sampleRate) + 5_000 // expected duration + 5s grace
                    while (currentAudioTrack === track) {
                        val head = track.playbackHeadPosition
                        if (head >= writtenFrames) break
                        if (System.currentTimeMillis() > deadline) break
                        kotlinx.coroutines.delay(150)
                    }
                }
                try { track.stop() } catch (_: Exception) {}
                try { track.release() } catch (_: Exception) {}
                if (currentAudioTrack === track) currentAudioTrack = null
                _isSpeaking.value = false
            } catch (_: Exception) {
                if (currentAudioTrack !== null) {
                    try { currentAudioTrack?.release() } catch (_: Exception) {}
                }
                currentAudioTrack = null
                _isSpeaking.value = false
            }
        }
    }

    fun stopSpeaking() {
        try {
            currentAudioTrack?.stop()
            currentAudioTrack?.release()
        } catch (_: Exception) {}
        currentAudioTrack = null
        _isSpeaking.value = false
    }

    private fun updateSession(session: ChatSession) {
        _currentSession.value = session
        _sessions.value = _sessions.value.map {
            if (it.id == session.id) session else it
        }
        saveSessions()
    }

    private fun getSystemPrompt(): String {
        val base = """You are MiMo, an AI assistant developed by Xiaomi. You are helpful, creative, and friendly.

When thinking through complex problems, structure your reasoning in these phases:

1. Deconstruct
· Identify the core subject and key entities
· List available tools/constraints mentioned
· Clarify what is actually being asked

2. Evaluate / Check / Brainstorm
· Assess feasibility and safety implications
· Consider multiple approaches (practical, creative, humorous)
· Eliminate clearly unworkable options
· Identify the best path forward

3. Draft / Build Response
· Outline the structure of your answer
· Draft key points for each section
· Self-correct: ensure tone matches the request
· Balance humor with substance when appropriate

4. Polish
· Refine wording for clarity and impact
· Ensure logical flow between sections
· Verify factual accuracy
· Finalize the output

Use this structure especially for complex, multi-part, or creative questions. For simple questions, answer directly without over-structuring."""

        // Workspace files (IDENTITY/SOUL/TOOLS/HEARTBEAT) are ONLY for Agent mode.
        // Normal chat uses the embedded prompt above and must not touch the workspace dir.
        val isAgentMode = _currentModel.value.contains("agent") && agentEngine != null
        val agentCtx = if (isAgentMode) agentEngine?.getAgentContext() ?: "" else ""
        val phoneToolDoc = if (com.mimo.app.agent.AgentEngine.PHONE_AGENT_ENABLED) {
            "- execute_phone_action: {\"instruction\":\"Chinese command like 打开微信 or 点击搜索按钮\"}\n" +
            "  Only pass the instruction, the API key is configured automatically.\n"
        } else ""
        val toolCallInstructions = if (isAgentMode) {
            val taskList = agentTaskManager.tasks.value
            val taskListText = if (taskList.isNotEmpty()) {
                taskList.joinToString("\n") { t ->
                    val status = when (t.status) {
                        com.mimo.app.agent.CheckTaskStatus.PENDING -> "pending"
                        com.mimo.app.agent.CheckTaskStatus.IN_PROGRESS -> "in_progress"
                        com.mimo.app.agent.CheckTaskStatus.DONE -> "done"
                        com.mimo.app.agent.CheckTaskStatus.CANCELLED -> "cancelled"
                    }
                    "- ${t.label} [$status] ${t.title}"
                }
            } else "(empty — no tasks yet)"

            """

You have access to local device tools. When the user asks you to perform file operations or use tools, you MUST respond with a SINGLE raw JSON object. No other text.

CRITICAL OUTPUT RULES:
- Output ONLY the raw JSON object, nothing else
- Do NOT wrap in markdown code blocks (no ```json)
- Do NOT use > quote prefixes
- Do NOT add any explanation before or after the JSON
- Do NOT use any formatting, just the plain JSON

JSON format:
{"thinking":"your reasoning","tool_calls":[{"tool":"tool_name","args":{"key":"value"},"reason":"why"}],"response":"when using tools: one short sentence telling the user what you are about to do (shown live); when no tools: your full final answer"}

CURRENT TASK CHECKLIST:
$taskListText

TASK MANAGEMENT:
For any multi-step work, FIRST add all tasks with add_task, then work through them one by one.
- add_task: {"title":"task description"} — returns the task ID (e.g. T1)
- update_task: {"id":1,"status":"in_progress"} — mark a task as in_progress when you start it
- update_task: {"id":1,"status":"done"} — mark a task as done when finished
- strike_task: {"id":1} — remove a task that cannot be completed (counts as failure)

IMPORTANT - Tool arguments:
${phoneToolDoc}- read_file: {"path":"file path"}
- write_file: {"path":"file path","content":"file content"}
- list_files: {"path":"directory path"}
- delete_file: {"path":"file path"}
- move_file: {"source":"from","destination":"to"}
- copy_file: {"source":"from","destination":"to"}
- search_files: {"pattern":"search pattern"}
- get_file_info: {"path":"file path"}
- grep: {"pattern":"regex or literal","path":"dir (optional)","include":"*.ext (optional)"}
- edit_file: {"path":"file path","old_text":"exact existing text","new_text":"replacement"}
- current_time: {}
- download_file: {"url":"https://...","filename":"name.ext (optional)"}
- view_media: {"path":"path/to/media","question":"optional — what to look for or ask"}
  Use on any image/audio/video file to see, transcribe, or analyze its content autonomously.
- open_app: {"package":"com.package.name"}
- list_apps: {}
- request_permission: {"permission":"accessibility|overlay|storage|projection|notification|mic","reason":"why it is needed"}
  Use when you are blocked by a missing system permission or a tool reports NEED_PERMISSION. The user will be offered a jump to system Settings.
- get_location: {} — Get GPS coordinates
- set_alarm: {"hour":8,"minute":30,"label":"起床"} — Set alarm clock
- set_timer: {"seconds":300,"label":"计时"} — Set countdown timer
- set_volume: {"level":10} — Set media volume (0-15)
- get_volume: {} — Get current volume
- toggle_flashlight: {"state":"on"} — Toggle flashlight on/off
- get_network_info: {} — WiFi/mobile data status
- get_battery_info: {} — Battery level, charging, temperature
- get_device_details: {} — RAM, storage, screen, CPU info
- make_call: {"number":"10086"} — Open dialer (requires confirmation)
- open_settings: {"page":"wifi"} — Open system settings (wifi|bluetooth|location|sound|display|battery|apps|storage|about)
- share_text: {"text":"content"} — Open share sheet
- vibrate: {"milliseconds":200} — Vibrate device
- clipboard_read: {} — Read clipboard content
- clipboard_write: {"text":"content"} — Write to clipboard
- set_brightness: {"level":128} — Set screen brightness (0-255)
- set_sound_mode: {"mode":"normal"} — normal|vibrate|silent
- get_sound_mode: {} — Get ringer mode
- close_app: {"package":"com.example.app"} — Force-stop an app
- get_app_info: {"package":"com.example.app"} — App version, size, dates
- search_contacts: {"query":"张三"} — Search contacts by name
- get_alarms: {} — Open alarm app
- get_step_count: {} — Check step sensor
- get_screen_state: {} — Brightness, timeout, rotation
- set_screen_timeout: {"seconds":60} — Set screen timeout
- get_storage_usage: {} — Total/used/free storage
- install_apk: {"path":"/sdcard/Download/app.apk"} — Install APK (user confirms)
- uninstall_app: {"package":"com.example.app"} — Uninstall app (user confirms)
- download_and_install: {"url":"https://example.com/app.apk"} — Download APK + install (user confirms)
- run_shell: {"command":"ls -la","timeout":30} — Execute shell command (no root)
- run_python: {"code":"print('hello')"} — Run Python via Termux (must have Termux+python installed)
- run_python: {"path":"/sdcard/知白/script.py"} — Run Python file via Termux
- run_node: {"code":"console.log('hi')"} — Run Node.js via Termux (must have Termux+nodejs installed)

Workspace: ${agentEngine?.workspaceDir?.absolutePath ?: "/sdcard/知白/"}
""".trimIndent()
        } else ""
        // Custom prompt always goes LAST with explicit override priority so the default
        // prompt can never wash it out (it is user-owned configuration, not a suggestion).
        val customPart = if (_customPrompt.value.isNotBlank()) {
            """

${'='}
USER CUSTOM INSTRUCTIONS (HIGHEST PRIORITY)
${'='}
The following instructions are configured by the user and OVERRIDE any conflicting
default instructions, persona, tone, or formatting rules above. If anything in the
sections above contradicts these instructions, ALWAYS follow these instead.

${_customPrompt.value.trim()}"""
        } else ""
        val agentPart = if (isAgentMode && agentCtx.isNotBlank()) "\n\n$agentCtx" else ""
        val faithfulPart = if (_strictFaithful.value) {
            "\n\n严格参考内容信息，不虚构或者加额外的个人推测。When the user provides content (images, video, audio, files, or text), describe and analyze ONLY what is actually present in it. Never fabricate details or add speculative personal assumptions beyond the provided content."
        } else ""

        // Long-term memory
        val memoryPart = if (_prefLongTermMemory.value && _memoryContent.value.isNotBlank()) {
            "\n\n${'='}\nLONG-TERM MEMORY (user's accumulated knowledge and preferences)\n${'='}\n${_memoryContent.value.trim()}"
        } else ""

        // Model habit (suffix)
        val habitPart = if (_prefModelHabit.value.isNotBlank()) {
            "\n\nHabit: Always end every reply with \"${_prefModelHabit.value}\". This is a user-configured habit, apply it consistently."
        } else ""

        // Scenario preference
        val scenarioPart = when (_prefScenario.value) {
            "code" -> "\n\nUser primarily uses this for programming. Prioritize code accuracy, include code examples, use technical language."
            "work" -> "\n\nUser primarily uses this for work. Be professional, concise, and action-oriented."
            "study" -> "\n\nUser primarily uses this for studying. Be educational, explain step by step, encourage understanding."
            "daily" -> "\n\nUser primarily uses this for daily conversation. Be friendly, casual, and warm."
            else -> ""
        }

        return base + agentPart + toolCallInstructions + faithfulPart + memoryPart + habitPart + scenarioPart + customPart
    }

    fun getApiModel(): String {
        // Agent variants are local aliases: any "<base>-agent" maps to "<base>"
        val cur = _currentModel.value
        return if (cur.endsWith("-agent")) cur.removeSuffix("-agent") else cur
    }

    private fun isBalanceError(e: Exception): Boolean {
        val msg = e.message?.lowercase() ?: ""
        return msg.contains("402") || msg.contains("balance") || msg.contains("insufficient") ||
                msg.contains("quota") || msg.contains("credit") || msg.contains("payment")
    }

    private fun extractJson(raw: String): String {
        var text = raw.trim()
        // Remove markdown code block wrapper
        if (text.startsWith("```")) {
            val firstNewline = text.indexOf('\n')
            if (firstNewline > 0) text = text.substring(firstNewline + 1)
            if (text.endsWith("```")) text = text.dropLast(3)
            text = text.trim()
        }
        // Remove > line prefixes
        text = text.lines().map { line ->
            if (line.trimStart().startsWith("> ")) line.trimStart().removePrefix("> ")
            else line
        }.joinToString("\n").trim()
        // Extract first JSON object
        val start = text.indexOf('{')
        if (start < 0) return text
        var depth = 0
        for (i in start until text.length) {
            if (text[i] == '{') depth++
            else if (text[i] == '}') depth--
            if (depth == 0) return text.substring(start, i + 1)
        }
        return text.substring(start)
    }

    private fun getActiveApiService(): MiMoApiService {
        return if (_currentModel.value.contains("agent") && _agentApiKey.value.isNotBlank()) {
            agentChatService
        } else {
            apiService
        }
    }

    private fun saveSessions() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Clean up: remove empty streaming messages and reset streaming state
                val cleanSessions = _sessions.value.map { session ->
                    session.copy(messages = session.messages
                        .filterNot { it.isStreaming && it.content.isBlank() }
                        .map { if (it.isStreaming) it.copy(isStreaming = false) else it }
                    )
                }
                val json = gson.toJson(cleanSessions)
                val file = File(context.filesDir, "mimo_sessions.json")
                file.writeText(json)
                // Also write encrypted backup to external storage
                com.mimo.app.data.ChatBackupManager.backup(context, json)
            } catch (_: Exception) {}
        }
    }

    private suspend fun loadSessions(): List<ChatSession>? {
        return try {
            val file = File(context.filesDir, "mimo_sessions.json")
            val parseAndClean: (String) -> List<ChatSession>? = { json ->
                val type = com.google.gson.reflect.TypeToken.getParameterized(List::class.java, ChatSession::class.java).type
                val sessions: List<ChatSession>? = gson.fromJson(json, type)
                sessions?.map { session ->
                    session.copy(messages = session.messages
                        .filterNot { it.isStreaming && it.content.isBlank() }
                        .map { if (it.isStreaming) it.copy(isStreaming = false) else it }
                    )
                }
            }

            if (file.exists()) {
                val json = file.readText()
                if (json.isNotBlank()) {
                    parseAndClean(json)
                } else {
                    // File empty → try backup
                    tryRestoreFromBackup(file, parseAndClean)
                }
            } else {
                val prefs = context.dataStore.data.first()
                val sessionsJson = prefs[SESSIONS_KEY]
                if (!sessionsJson.isNullOrBlank()) {
                    val sessions = parseAndClean(sessionsJson)
                    if (sessions != null) {
                        file.writeText(sessionsJson)
                        context.dataStore.edit { it.remove(SESSIONS_KEY) }
                    }
                    sessions
                } else {
                    // No file, no DataStore → try encrypted backup
                    tryRestoreFromBackup(file, parseAndClean)
                }
            }
        } catch (_: Exception) { null }
    }

    private fun tryRestoreFromBackup(
        targetFile: File,
        parse: (String) -> List<ChatSession>?
    ): List<ChatSession>? {
        val backupJson = com.mimo.app.data.ChatBackupManager.restore(context) ?: return null
        val sessions = parse(backupJson) ?: return null
        // Write restored data to normal location
        try { targetFile.writeText(backupJson) } catch (_: Exception) { }
        return sessions
    }

    private fun uriToBase64(uri: Uri): String? {
        return try {
            val context = getApplication<Application>()
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()

            // Resize if too large
            val maxSize = 1024
            val scale = minOf(maxSize.toFloat() / bitmap.width, maxSize.toFloat() / bitmap.height, 1f)
            val resized = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * scale).toInt(),
                    (bitmap.height * scale).toInt(),
                    true
                )
            } else bitmap

            val outputStream = ByteArrayOutputStream()
            resized.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    /** Copy a picker content:// URI into app-private storage so it survives process death. */
    private fun persistImage(uri: Uri): String? {
        return try {
            val dir = File(context.filesDir, "chat_images").apply { mkdirs() }
            val ext = when (context.contentResolver.getType(uri)) {
                "image/png" -> "png"
                "image/webp" -> "webp"
                else -> "jpg"
            }
            val dest = File(dir, "img_${System.currentTimeMillis()}_${(0..9999).random()}.$ext")
            val input = context.contentResolver.openInputStream(uri) ?: return uri.toString()
            input.use { ins ->
                dest.outputStream().use { out -> ins.copyTo(out) }
            }
            dest.absolutePath
        } catch (_: Exception) {
            uri.toString()
        }
    }

    /**
     * Best-effort vision capability check by model id.
     * Known multimodal families (flash/pro/ultraspeed, any version) consume image_url parts;
     * everything else (future text-only models, embedding-style ids, etc.) gets text extraction first.
     */
    private fun supportsVision(modelId: String): Boolean {
        val m = modelId.lowercase()
        if (m == "asr" || m.startsWith("tts")) return false
        if (m.contains("ultraspeed")) return false // UltraSpeed is text-only
        return m.contains("flash") || m.contains("pro") ||
                m.contains("vision") || m.contains("vl-") || m.contains("-vl")
    }

    /**
     * Ask the active (vision-capable) model to convert images into a text document,
     * so non-vision models still receive the information. Returns null on failure
     * (caller then sends images as-is).
     */
    private suspend fun extractImageContent(images: List<String>): String? {
        return try {
            val contentParts = mutableListOf<com.mimo.app.data.model.ImageContent>()
            images.take(6).forEach { b64 ->
                contentParts.add(
                    com.mimo.app.data.model.ImageContent(
                        type = "image_url",
                        imageUrl = com.mimo.app.data.model.ImageUrl(url = "data:image/jpeg;base64,$b64")
                    )
                )
            }
            contentParts.add(
                com.mimo.app.data.model.ImageContent(
                    type = "text",
                    text = "请提取图片中的全部内容并整理成结构化文本文档：\n" +
                            "1. 图中所有文字（原文照录，保留原有结构如表格/列表/标题）\n" +
                            "2. 若无文字，简要客观描述图片内容\n" +
                            "只输出整理后的文档内容，不要任何开场白或解释。"
                )
            )
            val request = ChatRequest(
                model = "mimo-v2.6-flash",
                messages = listOf(
                    com.mimo.app.data.model.Message(role = "user", content = contentParts)
                ),
                maxCompletionTokens = 4096,
                temperature = 0.2f,
                stream = false,
                thinking = ThinkingConfig(type = "disabled")
            )
            val response = getActiveApiService().chatCompletionStructured(request)
            val raw = response.choices.firstOrNull()?.message?.content?.toString()?.trim()
            raw?.takeIf { it.isNotBlank() && it != "null" }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Raw-bytes base64 for audio/video (BitmapFactory can't decode them — it returned null,
     * so audio/video were never actually sent). API limit: base64 string <= 50 MB (~37.5 MB file).
     */
    private fun uriToRawBase64(uri: Uri): String {
        val context = getApplication<Application>()
        val maxBytes = 37L * 1024 * 1024
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw java.io.IOException("Cannot open file")
        inputStream.use { input ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val read = input.read(chunk)
                if (read < 0) break
                total += read
                if (total > maxBytes) {
                    throw java.io.IOException("File too large (max ~37 MB for video/audio)")
                }
                buffer.write(chunk, 0, read)
            }
            return Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP)
        }
    }
    //Are you OK?
    private fun readFileContent(uri: Uri): String? {
        return try {
            val context = getApplication<Application>()
            val mimeType = context.contentResolver.getType(uri) ?: ""

            // Only read text-based files
            val textTypes = setOf(
                "text/", "application/json", "application/xml", "application/javascript",
                "application/x-yaml", "application/yaml", "application/toml",
                "application/csv", "application/sql"
            )
            val isTextFile = textTypes.any { mimeType.startsWith(it) } ||
                    mimeType.endsWith("+xml") || mimeType.endsWith("+json")

            // Also check common text extensions
            val fileName = getFileName(context, uri).lowercase()
            val textExtensions = setOf(
                ".txt", ".md", ".json", ".xml", ".csv", ".yaml", ".yml", ".toml",
                ".js", ".ts", ".py", ".java", ".kt", ".c", ".cpp", ".h", ".css",
                ".html", ".htm", ".sql", ".sh", ".bat", ".ps1", ".rb", ".go", ".rs",
                ".swift", ".dart", ".lua", ".php", ".r", ".m", ".swift", ".log",
                ".cfg", ".conf", ".ini", ".env", ".gitignore", ".dockerfile"
            )
            val isTextByName = textExtensions.any { fileName.endsWith(it) }

            if (!isTextFile && !isTextByName) {
                return "[Binary file: $fileName (${mimeType})]"
            }

            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val bytes = inputStream.readBytes()
            inputStream.close()

            val maxSize = 100 * 1024
            if (bytes.size > maxSize) {
                String(bytes, 0, maxSize, Charsets.UTF_8) + "\n...(truncated)"
            } else {
                String(bytes, Charsets.UTF_8)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun getFileName(context: android.content.Context, uri: Uri): String {
        var name = "file"
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) {
                    name = it.getString(nameIndex) ?: name
                }
            }
        }
        return name
    }
}
